import random


class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """


class Memory:
    pass


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""


# DO NOT CHANGE ABOVE CODE OR FUNCTION SIGNATURE ELSE YOUR CODE WILL NOT RUN!
# except... some libraries can be imported

def bet(state: GameState, memory: Memory | None = None) -> tuple[int, Memory | None]:
    # Make random bets between the min bet and max bet
    my_index = state.index_to_action
    current_bet = max(state.bet_money) if state.bet_money else 0
    my_current_bet = state.bet_money[my_index] if my_index < len(
        state.bet_money) else 0
    my_stack = state.held_money[my_index] if my_index < len(
        state.held_money) else 0

    # Amount needed to call
    call_amount = current_bet - my_current_bet

    # Minimum raise is 2x the current bet (or big blind if no bet yet)
    # The bet_amount we return is what we're adding to the pot THIS turn
    if current_bet == 0:
        # No bet yet, minimum is the big blind
        min_raise = state.big_blind
    else:
        # Minimum raise: we need to bet call_amount + current_bet
        # This makes the total bet 2x the current_bet
        min_raise = call_amount + current_bet

    # Maximum bet is a reasonable raise or our entire stack
    total_pot = sum(state.bet_money) if state.bet_money else state.big_blind
    max_raise = min(total_pot * 3, my_stack)

    # Ensure max_raise is at least min_raise
    max_raise = max(min_raise, max_raise)

    # Always raise (this is the random BET bot, not call bot)
    if my_stack < min_raise:
        # Can't make minimum raise, go all-in
        bet_amount = my_stack
    else:
        # Raise: random amount between min_raise and max_raise
        bet_amount = random.randint(min_raise, max_raise)

    return (bet_amount, memory)
