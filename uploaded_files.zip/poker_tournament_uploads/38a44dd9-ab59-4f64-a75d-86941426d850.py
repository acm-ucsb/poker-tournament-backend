# <IMPORTS HERE>
import random
# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    def __init__(self):
        self.betting_mode = False


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""

def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    
    if memory is None:
        memory = Memory()
        memory.betting_mode = False


    if state.community_cards == []:
        memory.betting_mode = False
        # have a 7% chance to enter betting mode pre-flop
        if random.random() < 0.07:
            memory.betting_mode = True
        
        # alternatively, if your cards are both face cards, enter betting mode
        player_cards = state.player_cards
        rank1 = player_cards[0][0]
        rank2 = player_cards[1][0]
        face_cards = ['j', 'q', 'k', 'a']
        if rank1 in face_cards and rank2 in face_cards:
            memory.betting_mode = True
        
        # alternatively, also play pairs
        if rank1 == rank2:
            memory.betting_mode = True

        # alternatively, play suited connectors
        suit1 = player_cards[0][1]
        suit2 = player_cards[1][1]
        connectors = ['a', 'k', 'q', 'j', 't', '9', '8', '7', '6', '5', '4', '3', '2']
        if suit1 == suit2:
            index1 = connectors.index(rank1)
            index2 = connectors.index(rank2)
            if abs(index1 - index2) == 1:
                memory.betting_mode = True
        

    if memory.betting_mode:
        # on preflop, always call
        if state.community_cards == []:
            to_call = max(state.bet_money) - state.bet_money[state.index_to_action]
            return to_call, memory
        
        # on postflop, bet a random amount thats between 0.02 to 0.1 times of your held money
        # if checking is an option, check 50% of the time
        # if someone else bet, call 60% of the time
        
        else:
            bet_fraction = random.uniform(0.02, 0.1)
            bet_amount = int(state.held_money[state.index_to_action] * bet_fraction)
            to_call = max(state.bet_money) - state.bet_money[state.index_to_action]
            if to_call > 0:
                if random.random() < 0.6:
                    return to_call, memory
                else:
                    return -1, memory
            return (bet_amount, memory) if random.random() >= 0.5 else (0, memory)

    return -1, memory