# <IMPORTS HERE>

# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


def evaluate_hand_strength(my_cards: list[str], community_cards: list[str], num_players: int = 2) -> int:
    """
    Calculate hand equity as a percentage (1-100).
    Uses pre-flop equity table when no community cards, actual hand strength when cards are dealt.
    Considers number of players - more players = lower equity for same hand.
    
    Args:
        my_cards: Your 2 hole cards (e.g., ['ah', 'kc'])
        community_cards: Community cards on board (0-5 cards)
        num_players: Total number of players in the hand (default 2)
    
    Returns:
        Equity percentage (1-100) representing win probability against random opponents
    """
    if not my_cards or len(my_cards) == 0:
        return 1
    
    # If community cards are available, use actual hand evaluation
    if community_cards and len(community_cards) >= 3:
        base_equity = _get_post_flop_equity(my_cards, community_cards)
    else:
        # Pre-flop: use equity table
        base_equity = _get_equity_from_table(my_cards)
    
    # Adjust for number of opponents (softer penalties to avoid folding premium hands)
    num_opponents = max(1, num_players - 1)
    if num_opponents == 1:
        multiplier = 1.0
    elif num_opponents == 2:
        multiplier = 0.80  # Slightly less harsh
    elif num_opponents == 3:
        multiplier = 0.70  # More forgiving for 4-handed
    elif num_opponents == 4:
        multiplier = 0.60  # Better for 5-handed
    else:
        multiplier = 0.50  # Much less harsh for 6+ players (was 0.35)
    
    # Final equity with premium hand protection
    equity = int(base_equity * multiplier)
    
    # Premium hand protection - ensure top hands remain playable even with harsh multipliers
    if not community_cards:  # Pre-flop only
        # Check for premium pocket pairs
        if len(my_cards) == 2:
            rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
            c1, c2 = my_cards[0].lower(), my_cards[1].lower()
            r1, r2 = rank_vals.get(c1[0], 2), rank_vals.get(c2[0], 2)
            
            # Premium pocket pairs get minimum equity protection
            if r1 == r2:  # Pocket pair
                if r1 >= 14:  # AA
                    equity = max(equity, 45)  # Minimum 45% equity for aces
                elif r1 >= 13:  # KK
                    equity = max(equity, 40)  # Minimum 40% equity for kings
                elif r1 >= 12:  # QQ
                    equity = max(equity, 35)  # Minimum 35% equity for queens
    
    return max(1, min(equity, 100))


def _get_post_flop_equity(my_cards: list[str], community_cards: list[str]) -> float:
    """Evaluate actual hand strength when community cards are available"""
    try:
        # Get our best hand
        my_category, my_best_five = get_best_hand_from(my_cards, community_cards)
        
        # Check for draws (this is crucial!)
        flush_draw_outs = _count_flush_draw_outs(my_cards, community_cards)
        straight_draw_outs = _count_straight_draw_outs(my_cards, community_cards)
        
        # Convert hand category to equity percentage
        # Categories: 0=High Card, 1=Pair, 2=Two Pair, 3=Three of a Kind, 
        #           4=Straight, 5=Flush, 6=Full House, 7=Four of a Kind, 8=Straight Flush
        
        if my_category == 8:    # Straight Flush
            return 95.0
        elif my_category == 7:  # Four of a Kind  
            return 90.0
        elif my_category == 6:  # Full House
            return 85.0
        elif my_category == 5:  # Flush
            if _is_nut_flush(my_best_five, community_cards):
                return 80.0  # Nut flush - very strong
            else:
                # Non-nut flush - much more vulnerable due to reverse implied odds
                # Check how low our flush is
                rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
                flush_cards = [(rank_vals.get(card[0].lower(), 2), card[1].lower()) for card in my_best_five]
                our_high_card = max(rank for rank, suit in flush_cards)
                
                if our_high_card >= 13:  # King-high flush
                    return 65.0  # Still strong but not nut
                elif our_high_card >= 11:  # Jack/Queen-high flush  
                    return 55.0  # Decent but vulnerable
                elif our_high_card >= 9:   # 9/Ten-high flush
                    return 50.0  # Weak flush, very vulnerable
                else:  # 8-high or lower flush
                    base_equity = 45.0  # Baby flush, extremely vulnerable
                
                # Additional penalty for paired boards (full house possible)
                community_ranks = [rank_vals.get(card[0].lower(), 2) for card in community_cards]
                from collections import Counter
                rank_counts = Counter(community_ranks)
                has_pair_on_board = any(count >= 2 for count in rank_counts.values())
                
                if has_pair_on_board:
                    base_equity -= 5.0  # Extra penalty on paired boards
                
                return max(base_equity, 35.0)  # Minimum floor for any flush
        elif my_category == 4:  # Straight
            if _is_nut_straight(my_best_five, community_cards):
                return 75.0  # Nut straight - very strong
            else:
                return 65.0  # Non-nut straight - vulnerable to better straights
        elif my_category == 3:  # Three of a Kind
            # Check if this is a set of premium cards (trips with pocket pair)
            rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
            
            # Get the three of a kind rank
            from collections import Counter
            all_ranks = [rank_vals.get(card[0].lower(), 2) for card in my_cards + community_cards]
            rank_counts = Counter(all_ranks)
            trips_rank = max([rank for rank, count in rank_counts.items() if count >= 3])
            
            # Premium trips get higher equity
            if trips_rank >= 14:  # Trip Aces
                return 75.0
            elif trips_rank >= 13:  # Trip Kings
                return 70.0
            elif trips_rank >= 12:  # Trip Queens
                return 65.0
            else:
                return 60.0
        elif my_category == 2:  # Two Pair
            # Two pair strength varies greatly - need to evaluate which pairs we have
            base_equity = _evaluate_two_pair_strength(my_cards, community_cards, my_best_five)
            return base_equity + _calculate_draw_bonus(flush_draw_outs, straight_draw_outs, len(community_cards))
        elif my_category == 1:  # One Pair
            # Pair strength matters - consider both pair rank and kicker
            pair_rank = _extract_pair_rank(my_best_five)
            kicker_strength = _get_kicker_strength(my_cards, my_best_five, pair_rank)
            
            # Top pair (pair matches highest community card)
            if _is_top_pair(pair_rank, community_cards):
                if kicker_strength >= 13:      # Top pair, King+ kicker (like AK on A93)
                    base_equity = 75.0
                elif kicker_strength >= 11:    # Top pair, Jack+ kicker  
                    base_equity = 65.0
                elif kicker_strength >= 9:     # Top pair, 9+ kicker
                    base_equity = 55.0
                else:                          # Top pair, weak kicker
                    base_equity = 45.0
                return base_equity + _calculate_draw_bonus(flush_draw_outs, straight_draw_outs, len(community_cards))
            
            # Overpair (pocket pair higher than board)
            elif _is_overpair(pair_rank, community_cards):
                if pair_rank >= 12:           # QQ+ overpair
                    base_equity = 80.0
                elif pair_rank >= 10:         # TT-JJ overpair  
                    base_equity = 70.0
                else:                         # 99- overpair
                    base_equity = 60.0
                return base_equity + _calculate_draw_bonus(flush_draw_outs, straight_draw_outs, len(community_cards))
            
            # Middle/bottom pair or weak pair
            else:
                base_equity = 35.0 if pair_rank >= 10 else (25.0 if pair_rank >= 7 else 20.0)
                return base_equity + _calculate_draw_bonus(flush_draw_outs, straight_draw_outs, len(community_cards))
        else:  # High Card (0)
            # High card strength based on highest card
            high_card = _extract_high_card(my_best_five)
            base_equity = 20.0 if high_card >= 14 else (15.0 if high_card >= 13 else (12.0 if high_card >= 12 else 8.0))
            
            # High card hands can still have strong draws!
            return base_equity + _calculate_draw_bonus(flush_draw_outs, straight_draw_outs, len(community_cards))
                
    except Exception:
        # If hand evaluation fails, fall back to pre-flop equity
        return _get_equity_from_table(my_cards)


def _extract_pair_rank(five_cards: list[str]) -> int:
    """Extract the rank of the pair from a pair hand"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        ranks = [rank_vals.get(card[0].lower(), 2) for card in five_cards]
        from collections import Counter
        counts = Counter(ranks)
        # Find the rank that appears twice (the pair)
        for rank, count in counts.items():
            if count == 2:
                return rank
        return 2  # Default to lowest pair
    except:
        return 2


def _extract_high_card(five_cards: list[str]) -> int:
    """Extract the highest card rank from a high card hand"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        ranks = [rank_vals.get(card[0].lower(), 2) for card in five_cards]
        return max(ranks)
    except:
        return 2


def _get_kicker_strength(my_cards: list[str], best_five: list[str], pair_rank: int) -> int:
    """Get the strength of the kicker (highest non-pair card in hole cards)"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        # Get ranks of hole cards
        hole_ranks = [rank_vals.get(card[0].lower(), 2) for card in my_cards]
        
        # Find the kicker (the card that's not the pair)
        kickers = [rank for rank in hole_ranks if rank != pair_rank]
        
        return max(kickers) if kickers else 2
    except:
        return 2


def _is_top_pair(pair_rank: int, community_cards: list[str]) -> bool:
    """Check if the pair rank matches the highest community card"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        if not community_cards:
            return False
            
        # Get highest community card rank
        community_ranks = [rank_vals.get(card[0].lower(), 2) for card in community_cards]
        highest_community = max(community_ranks)
        
        return pair_rank == highest_community
    except:
        return False


def _is_overpair(pair_rank: int, community_cards: list[str]) -> bool:
    """Check if the pair rank is higher than all community cards"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        if not community_cards:
            return True  # No community cards means any pair is an overpair
            
        # Get highest community card rank
        community_ranks = [rank_vals.get(card[0].lower(), 2) for card in community_cards]
        highest_community = max(community_ranks)
        
        return pair_rank > highest_community
    except:
        return False


def _count_flush_draw_outs(my_cards: list[str], community_cards: list[str]) -> int:
    """Count how many cards we need for a flush draw"""
    try:
        all_cards = my_cards + community_cards
        
        # Count suits
        suit_counts = {}
        for card in all_cards:
            suit = card[1].lower()
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for flush draws
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        if max_suit_count == 4:
            return 9  # Flush draw - 9 outs
        elif max_suit_count == 3 and len(community_cards) == 3:  # Flop
            return 10  # Backdoor flush draw (need runner-runner)
        else:
            return 0
    except:
        return 0


def _count_straight_draw_outs(my_cards: list[str], community_cards: list[str]) -> int:
    """Count outs for straight draws"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        all_cards = my_cards + community_cards
        ranks = sorted(set(rank_vals.get(card[0].lower(), 2) for card in all_cards))
        
        # Count potential straights
        max_outs = 0
        
        # Check all possible 5-card straights
        for start_rank in range(2, 11):  # 2-3-4-5-6 through T-J-Q-K-A
            straight_ranks = set(range(start_rank, start_rank + 5))
            
            # Special case for wheel (A-2-3-4-5)
            if start_rank == 2:
                straight_ranks = {14, 2, 3, 4, 5}
            
            # How many cards do we have for this straight?
            cards_in_straight = len(straight_ranks.intersection(set(ranks)))
            
            if cards_in_straight == 4:
                # Open-ended or gutshot straight draw
                missing_ranks = straight_ranks - set(ranks)
                if len(missing_ranks) == 1:
                    missing_rank = list(missing_ranks)[0]
                    # Check if it's open-ended (8 outs) or gutshot (4 outs)
                    if missing_rank in [min(straight_ranks), max(straight_ranks)]:
                        max_outs = max(max_outs, 8)  # Open-ended
                    else:
                        max_outs = max(max_outs, 4)  # Gutshot
        
        return max_outs
    except:
        return 0


def _evaluate_two_pair_strength(my_cards: list[str], community_cards: list[str], best_five: list[str]) -> float:
    """Evaluate the strength of a two pair hand"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        # Get all ranks in the hand
        all_ranks = [rank_vals.get(card[0].lower(), 2) for card in best_five]
        
        # Count ranks to find the two pairs
        from collections import Counter
        rank_counts = Counter(all_ranks)
        pairs = [rank for rank, count in rank_counts.items() if count == 2]
        pairs.sort(reverse=True)  # Highest pair first
        
        if len(pairs) != 2:
            return 45.0  # Fallback
        
        high_pair = pairs[0]
        low_pair = pairs[1]
        
        # Get community card ranks to understand board texture
        community_ranks = [rank_vals.get(card[0].lower(), 2) for card in community_cards]
        community_rank_counts = Counter(community_ranks)
        
        # Check what pairs are on the board vs in our hand
        my_hand_ranks = [rank_vals.get(card[0].lower(), 2) for card in my_cards]
        
        # Categorize the two pair strength
        board_pairs = [rank for rank, count in community_rank_counts.items() if count >= 2]
        
        if len(board_pairs) >= 1:
            # There's a pair on the board
            board_pair = max(board_pairs)
            
            if board_pair == high_pair:
                # We have the board pair + our own pair
                if low_pair in my_hand_ranks and my_hand_ranks.count(low_pair) == 2:
                    # We have pocket pair + board pair (like 22 on KK9)
                    if low_pair <= 6:  # Pocket pairs 22-66
                        return 25.0
                    elif low_pair <= 10:  # Pocket pairs 77-TT
                        return 35.0
                    else:  # Pocket pairs JJ+
                        return 55.0
                else:
                    # We have one card matching board pair (like Q2 on KK92)
                    our_card_in_pair = any(rank == board_pair for rank in my_hand_ranks)
                    if our_card_in_pair:
                        # We have bottom two pair (terrible) - even worse if very low pair
                        if low_pair <= 5:  # Bottom pair is 5 or lower
                            return 15.0
                        else:
                            return 20.0
                    else:
                        # Very weird case
                        return 25.0
        else:
            # No pairs on board - we made two pair with our cards + board
            if all(rank in my_hand_ranks for rank in pairs):
                # Both pairs from our hole cards (impossible with 2 cards)
                return 45.0
            else:
                # Standard two pair - one or both pairs involve board cards
                if high_pair >= 12:  # Top pair is QQ+
                    return 55.0
                elif high_pair >= 9:  # Top pair is 99-JJ
                    return 45.0
                else:  # Lower two pair
                    return 35.0
        
        return 30.0  # Conservative fallback
        
    except:
        return 30.0  # Conservative fallback if anything fails


def _calculate_draw_bonus(flush_outs: int, straight_outs: int, num_community_cards: int = 3) -> float:
    """Calculate equity bonus from draws"""
    try:
        total_outs = 0
        
        # Add flush outs
        if flush_outs == 9:  # Flush draw
            total_outs += 9
        elif flush_outs == 10:  # Backdoor flush
            total_outs += 2  # Much weaker
        
        # Add straight outs (but don't double-count if flush+straight draw)
        if straight_outs == 8:  # Open-ended straight draw
            total_outs += 8
        elif straight_outs == 4:  # Gutshot
            total_outs += 4
        
        # Combo draws are very strong
        if flush_outs >= 9 and straight_outs >= 4:
            total_outs = min(total_outs, 15)  # Cap at 15 outs for combo draws
        
        # Convert to equity: roughly 2% per out on flop, 4% per out on turn
        if num_community_cards == 3:  # Flop
            equity_bonus = total_outs * 2.0  # 2% per out
        else:  # Turn (4 cards) or River (5 cards)
            equity_bonus = total_outs * 4.0 if num_community_cards == 4 else 0.0
        
        return min(equity_bonus, 50.0)  # Cap bonus at 50%
    except:
        return 0.0


def _is_nut_flush(my_best_five: list[str], community_cards: list[str]) -> bool:
    """Check if we have the nut (highest possible) flush"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        # Get the suits and ranks from our flush
        flush_cards = [(rank_vals.get(card[0].lower(), 2), card[1].lower()) for card in my_best_five]
        
        # Find the flush suit (all cards should have same suit for a flush)
        flush_suit = flush_cards[0][1]
        if not all(card[1] == flush_suit for card in flush_cards):
            return False  # Not a flush
        
        # Get our highest card in the flush
        our_high_card = max(rank for rank, suit in flush_cards)
        
        # Check if we have the Ace (highest possible card)
        if our_high_card == 14:  # Ace
            return True
        
        # If we don't have the Ace, check if Ace is available in remaining deck
        # Get all cards of the flush suit that are visible (community + our hand)
        all_visible_cards = my_best_five + community_cards
        visible_flush_cards = [card for card in all_visible_cards if card[1].lower() == flush_suit]
        visible_ranks = [rank_vals.get(card[0].lower(), 2) for card in visible_flush_cards]
        
        # If Ace of this suit is not visible, we might not have the nut flush
        if 14 not in visible_ranks:
            return False  # Ace is still out there
        
        # If Ace is visible but not in our hand, we don't have nut flush
        return our_high_card == 14
        
    except:
        return False  # Conservative - assume not nut flush if error


def _is_nut_straight(my_best_five: list[str], community_cards: list[str]) -> bool:
    """Check if we have the nut (highest possible) straight"""
    try:
        rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
        
        # Get ranks from our straight
        straight_ranks = sorted([rank_vals.get(card[0].lower(), 2) for card in my_best_five])
        
        # Check if this is actually a straight
        if not (straight_ranks == list(range(straight_ranks[0], straight_ranks[0] + 5)) or 
                straight_ranks == [2, 3, 4, 5, 14]):  # Wheel straight
            return False  # Not a straight
        
        # Check for the highest possible straights
        if straight_ranks == [10, 11, 12, 13, 14]:  # Broadway (T-J-Q-K-A)
            return True
        
        # For other straights, check if a higher straight is possible
        # Get all visible ranks
        all_visible_cards = my_best_five + community_cards
        visible_ranks = set(rank_vals.get(card[0].lower(), 2) for card in all_visible_cards)
        
        # Check if higher straights are possible with visible cards
        our_high_card = max(straight_ranks) if straight_ranks != [2, 3, 4, 5, 14] else 5  # Wheel high card is 5
        
        # Check possible higher straights
        for high_card in range(our_high_card + 1, 15):  # Check higher possible straights
            if high_card == 14:  # Ace high straight
                required_ranks = {10, 11, 12, 13, 14}
            else:
                required_ranks = set(range(high_card - 4, high_card + 1))
            
            # If all required ranks for a higher straight are visible, we don't have the nuts
            if required_ranks.issubset(visible_ranks):
                return False
        
        return True  # No higher straight is possible with visible cards
        
    except:
        return False  # Conservative - assume not nut straight if error


def _get_equity_from_table(my_cards: list[str]) -> float:
    """Simple equity lookup table - returns equity percentage (0-100)"""
    if not my_cards or len(my_cards) != 2:
        return 20.0
    
    # Parse hole cards
    rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
    c1, c2 = my_cards[0].lower(), my_cards[1].lower()
    r1, r2 = rank_vals.get(c1[0], 2), rank_vals.get(c2[0], 2)
    s1, s2 = c1[1], c2[1]
    
    high_rank = max(r1, r2)
    low_rank = min(r1, r2) 
    suited = (s1 == s2)
    
    # Pocket pairs
    if r1 == r2:
        if high_rank >= 14:   return 85.0  # AA
        elif high_rank >= 13: return 82.0  # KK  
        elif high_rank >= 12: return 79.0  # QQ
        elif high_rank >= 11: return 76.0  # JJ
        elif high_rank >= 10: return 72.0  # TT
        elif high_rank >= 9:  return 68.0  # 99
        elif high_rank >= 8:  return 64.0  # 88
        elif high_rank >= 7:  return 60.0  # 77
        elif high_rank >= 6:  return 56.0  # 66
        else:                 return 50.0  # 22-55
    
    # Ace hands
    elif high_rank == 14:
        if low_rank >= 13:   return 65.0 if suited else 61.0  # AK
        elif low_rank >= 12: return 62.0 if suited else 58.0  # AQ
        elif low_rank >= 11: return 59.0 if suited else 55.0  # AJ
        elif low_rank >= 10: return 56.0 if suited else 52.0  # AT
        elif low_rank >= 9:  return 54.0 if suited else 49.0  # A9
        else:                return 45.0 if suited else 40.0  # A8-A2
    
    # King hands
    elif high_rank == 13:
        if low_rank >= 12:   return 57.0 if suited else 53.0  # KQ
        elif low_rank >= 11: return 54.0 if suited else 50.0  # KJ
        elif low_rank >= 10: return 51.0 if suited else 47.0  # KT
        else:                return 42.0 if suited else 37.0  # K9-K2
    
    # Queen hands  
    elif high_rank == 12:
        if low_rank >= 11:   return 50.0 if suited else 46.0  # QJ
        elif low_rank >= 10: return 47.0 if suited else 43.0  # QT
        else:                return 38.0 if suited else 33.0  # Q9-Q2
    
    # Jack hands
    elif high_rank == 11:
        if low_rank >= 10:   return 44.0 if suited else 40.0  # JT
        else:                return 35.0 if suited else 30.0  # J9-J2
    
    # Lower cards
    else:
        if suited and (high_rank - low_rank <= 1):  # Suited connectors
            return 32.0 + high_rank
        elif high_rank - low_rank <= 1:  # Offsuit connectors  
            return 28.0 + high_rank
        else:  # Random low cards
            return max(20.0, 25.0 + high_rank - (high_rank - low_rank))


""" Store any persistent data for your bot in this class """
class Memory:
    pass


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""

def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    # Validate game state to prevent crashes
    my_index = state.index_to_action
    
    # Bounds checking to prevent array access errors
    if my_index < 0 or my_index >= len(state.players):
        return (fold(), memory)  # Invalid index - fold to be safe
    
    if my_index >= len(state.held_money):
        return (fold(), memory)  # Mismatched array lengths - fold to be safe
    
    # Get stack and betting info
    my_stack = state.held_money[my_index]
    my_position = _get_position_type(state)
    call_cost = amount_to_call(state)
    num_players = len(state.players)
    
    # Get equity percentage (1-100) considering number of opponents
    equity = evaluate_hand_strength(state.player_cards, state.community_cards, num_players)
    
    # Position-adjusted equity thresholds
    if my_position == "small_blind":
        equity_bonus = 5  # Keep existing SB logic
        max_call_multiplier = 4
    elif my_position == "big_blind":
        equity_bonus = 3  # Keep existing BB logic
        max_call_multiplier = 3
    elif my_position == "early":
        equity_bonus = -5  # Early position penalty - reduced from -8 to allow premium hands
        max_call_multiplier = 1.5
    elif my_position == "middle":
        equity_bonus = -1  # Very slight penalty for middle position (was -2)
        max_call_multiplier = 2
    elif my_position == "late":
        equity_bonus = 5   # Late position bonus - can play looser
        max_call_multiplier = 3
    else:
        equity_bonus = 0   # Fallback for unknown positions
        max_call_multiplier = 2
    
    effective_equity = equity + equity_bonus
    
    # Stack-to-pot ratio considerations
    current_pot = sum(pot.value for pot in state.pots)  # Total pot value
    stack_bb_ratio = my_stack / state.big_blind if state.big_blind > 0 else 0
    
    # Calculate pot odds - what equity we need to break even
    pot_odds_equity = _calculate_required_equity(call_cost, current_pot) if call_cost > 0 else 0
    
    # Early return if we can't afford to call
    if call_cost > my_stack:
        if my_stack > 0:
            # We have some chips but not enough to call - lower threshold when forced to decide
            # Adjust threshold based on number of players - be tighter heads-up
            if num_players <= 2:  # Heads-up: be more selective
                threshold = 45 if stack_bb_ratio <= 10 else 55  
            else:  # Multi-way: use original thresholds
                threshold = 40 if stack_bb_ratio <= 10 else 50
            if effective_equity >= threshold:
                return (all_in(state), memory)
        return (fold(), memory)
    
    # If we have no chips left, we can only check/fold
    if my_stack == 0:
        return (check() if call_cost == 0 else fold(), memory)
    
    # Stack-aware betting decisions (lowered thresholds for more realistic play)
    # Adjust thresholds based on number of players - be tighter heads-up
    monster_threshold = 75 if num_players <= 2 else 70  # Higher bar heads-up
    strong_threshold = 60 if num_players <= 2 else 55   # Higher bar heads-up
    
    if effective_equity >= monster_threshold:  # Monster hands
        if stack_bb_ratio <= 15:  # Short stack - just shove
            bet_amount = all_in(state)
        elif call_cost == 0:  # No one has bet - build pot gradually
            # Pre-flop: start with moderate bet to build pot, not all-in
            if len(state.community_cards) == 0:  # Pre-flop
                bet_amount = _calculate_value_bet(state, 0.6)  # 60% pot bet to build
            elif stack_bb_ratio <= 30:  # Post-flop medium stack - larger bets
                bet_amount = all_in(state)
            else:
                bet_amount = _calculate_value_bet(state, 0.75)  # Bet 75% pot
        else:
            # Pre-flop vs action: raise instead of immediate all-in
            if len(state.community_cards) == 0:  # Pre-flop
                bet_amount = _calculate_raise(state)  # Make a raise, not shove
            else:
                bet_amount = all_in(state)  # Post-flop vs action - shove
            
    elif effective_equity >= strong_threshold:  # Strong hands  
        if stack_bb_ratio <= 20:  # Shorter stack
            # Pre-flop: even with short stack, try one raise before all-in
            if len(state.community_cards) == 0 and call_cost > 0:  # Pre-flop vs action
                bet_amount = _calculate_raise(state)
            else:
                bet_amount = all_in(state) if call_cost > 0 else _calculate_value_bet(state, 0.6)
        elif call_cost == 0:  # No one has bet
            bet_amount = _calculate_value_bet(state, 0.5)  # Bet 50% pot
        else:
            bet_amount = _calculate_raise(state)  # Make a reasonable raise
    
    elif effective_equity >= 45:  # Good hands (raised from 40 to be tighter)
        if call_cost == 0:
            bet_amount = _calculate_value_bet(state, 0.33)  # Small value bet
        elif call_cost <= my_stack and _should_call_based_on_pot_odds(effective_equity, call_cost, current_pot):
            # CRITICAL: Check for vulnerable made hands vs huge bets (reverse implied odds)
            # Calculate original pot size (before opponent's bet) for proper overbet detection
            original_pot = current_pot - call_cost
            if _is_vulnerable_made_hand_vs_overbet(state.player_cards, state.community_cards, call_cost, original_pot):
                bet_amount = fold()  # Fold vulnerable made hands vs huge bets
            else:
                bet_amount = call(state)
        else:
            bet_amount = fold()
    
    elif effective_equity >= 35:  # Medium hands (raised from 25 to be tighter)  
        if call_cost == 0:
            bet_amount = check()
        elif call_cost <= my_stack and _should_call_based_on_pot_odds(effective_equity, call_cost, current_pot):
            # Be more conservative: only call smaller bets with medium hands
            max_reasonable_call = state.big_blind * (max_call_multiplier * 0.75)  # 25% smaller calls
            if call_cost <= max_reasonable_call:
                bet_amount = call(state)
            else:
                bet_amount = fold()
        else:
            bet_amount = fold()
    
    elif effective_equity >= 25:  # Weak hands (raised from 20 to be tighter)
        if call_cost == 0:
            bet_amount = check()
        elif (my_position == "small_blind" and call_cost <= state.big_blind // 3 and  # Even cheaper SB calls
              call_cost <= my_stack and _should_call_based_on_pot_odds(effective_equity, call_cost, current_pot)):
            bet_amount = call(state)  # Very cheap SB completion only
        else:
            bet_amount = fold()
    
    else:  # Trash hands (now includes 20-24% equity)
        if call_cost == 0:
            bet_amount = check()
        else:
            bet_amount = fold()
    
    # Final validation - make sure our bet is legal
    bet_amount = _validate_bet(state, bet_amount)
    
    return (bet_amount, memory)


def _calculate_value_bet(state: GameState, pot_fraction: float) -> int:
    """Calculate a value bet as a fraction of the pot"""
    my_index = state.index_to_action
    my_stack = state.held_money[my_index]
    current_pot = sum(state.bet_money)
    
    # Calculate desired bet size
    desired_bet = int(current_pot * pot_fraction)
    
    # Make sure we can afford it and it meets minimum requirements
    min_bet = state.big_blind  # Minimum bet is usually the big blind
    max_bet = my_stack  # Can't bet more than we have
    
    if desired_bet < min_bet:
        desired_bet = min_bet
    
    if desired_bet > max_bet:
        desired_bet = max_bet
    
    return desired_bet if desired_bet > 0 else check()


def _calculate_raise(state: GameState) -> int:
    """Calculate a reasonable raise size (2-3x the current bet or pot-sized)"""
    my_index = state.index_to_action  
    my_stack = state.held_money[my_index]
    call_cost = amount_to_call(state)
    current_pot = sum(state.bet_money)
    
    # Raise to 2.5x current bet, or pot-sized, whichever is smaller
    current_max_bet = max(state.bet_money)
    raise_to_amount = max(current_max_bet * 2.5, current_pot)
    my_current_bet = state.bet_money[my_index]
    
    # How much more we need to put in
    additional_bet = int(raise_to_amount - my_current_bet)
    
    # Make sure we can afford it
    if additional_bet > my_stack:
        return all_in(state)
    
    # Make sure it meets minimum raise requirements  
    try:
        min_raise_amount = min_raise(state)
        if additional_bet < min_raise_amount:
            additional_bet = min_raise_amount
            
        if additional_bet > my_stack:
            return all_in(state)
            
    except:
        # If min_raise fails, fall back to call
        return call(state) if call_cost <= my_stack else fold()
    
    return additional_bet


def _calculate_required_equity(call_cost: int, current_pot: int) -> float:
    """Calculate the equity % needed to break even on a call"""
    if call_cost <= 0:
        return 0.0
    
    # Pot odds formula: call_cost / (current_pot + call_cost)
    # This gives us the % of the final pot we're risking
    total_pot_after_call = current_pot + call_cost
    required_equity = (call_cost / total_pot_after_call) * 100
    
    return required_equity


def _should_call_based_on_pot_odds(our_equity: float, call_cost: int, current_pot: int) -> bool:
    """Determine if we should call based on pot odds"""
    if call_cost <= 0:
        return True  # Free to call
    
    required_equity = _calculate_required_equity(call_cost, current_pot)
    
    # We need a small buffer for implied odds and to account for uncertainty
    # Add 2-5% buffer depending on bet size relative to pot
    bet_to_pot_ratio = call_cost / current_pot if current_pot > 0 else float('inf')
    
    if bet_to_pot_ratio >= 2.0:  # Very large bet (2x pot or more)
        buffer = 8.0  # Need 8% extra equity for huge bets
    elif bet_to_pot_ratio >= 1.0:  # Large bet (pot-sized or more)
        buffer = 5.0  # Need 5% extra equity  
    elif bet_to_pot_ratio >= 0.5:  # Medium bet (half pot)
        buffer = 3.0  # Need 3% extra equity
    else:  # Small bet
        buffer = 2.0  # Need 2% extra equity
    
    # Call if our equity exceeds required equity plus buffer
    return our_equity >= (required_equity + buffer)


def _is_vulnerable_made_hand_vs_overbet(my_cards: list[str], community_cards: list[str], call_cost: int, current_pot: int) -> bool:
    """
    Detect vulnerable made hands that should fold to huge overbets due to reverse implied odds
    Returns True if we should fold despite pot odds
    """
    try:
        # Calculate overbet size relative to pot
        bet_to_pot_ratio = call_cost / current_pot if current_pot > 0 else float('inf')
        
        # Only apply this logic to massive overbets (2x pot or more)
        if bet_to_pot_ratio < 2.0:
            return False
        
        # Get our hand category
        my_category, my_best_five = get_best_hand_from(my_cards, community_cards)
        
        # Check for vulnerable flush scenarios
        if my_category == 5:  # Flush
            if not _is_nut_flush(my_best_five, community_cards):
                # Non-nut flush vs huge overbet - check if it's weak
                rank_vals = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 't':10, 'j':11, 'q':12, 'k':13, 'a':14}
                flush_cards = [(rank_vals.get(card[0].lower(), 2), card[1].lower()) for card in my_best_five]
                our_high_card = max(rank for rank, suit in flush_cards)
                
                # Baby flushes (9-high or lower) should fold to huge overbets
                if our_high_card <= 9:
                    return True
                
                # Even Jack/Queen high flushes should fold to 3x+ pot overbets  
                if our_high_card <= 12 and bet_to_pot_ratio >= 3.0:
                    return True
        
        # Check for weak two pair vs huge bets
        elif my_category == 2:  # Two Pair
            # Two pair vs 4x+ pot overbet should be very careful
            if bet_to_pot_ratio >= 4.0:
                return True
        
        # Check for weak trips vs huge bets on dangerous boards
        elif my_category == 3:  # Three of a Kind
            # Check if board is dangerous (paired, suited, straight possibilities)
            if bet_to_pot_ratio >= 5.0:  # Only fold trips vs truly massive 5x+ overbets
                # Check if board has flush/full house possibilities
                suits = [card[1].lower() for card in community_cards]
                from collections import Counter
                suit_counts = Counter(suits)
                max_suit_count = max(suit_counts.values()) if suit_counts else 0
                
                # If 3+ cards of same suit on board and we face massive overbet
                if max_suit_count >= 3:
                    return True
        
        return False
        
    except Exception:
        return False  # Default to not folding on errors


def _validate_bet(state: GameState, proposed_bet: int) -> int:
    """Validate that the proposed bet is legal, adjust if necessary"""
    my_index = state.index_to_action
    my_stack = state.held_money[my_index]
    
    # Check if we can afford the bet
    if proposed_bet > my_stack:
        proposed_bet = my_stack  # All-in
    
    # SPECIAL CASE: All-in is always valid regardless of call amount
    if proposed_bet == my_stack and my_stack > 0:
        return proposed_bet  # All-in is always legal
    
    # Use the helper function to check if bet is valid
    if is_valid_bet(state, proposed_bet):
        return proposed_bet
    
    # If invalid, try safer alternatives
    call_cost = amount_to_call(state)
    
    if call_cost <= my_stack and is_valid_bet(state, call_cost):
        return call_cost  # Just call
    elif is_valid_bet(state, 0):
        return 0  # Check
    else:
        return -1  # Fold
def _get_position_type(state: GameState) -> str:
    """Determine the player's position type with detailed categories"""
    my_index = state.index_to_action
    sb_index = state.index_of_small_blind
    num_players = len(state.players)
    
    # Calculate big blind index (next after small blind)
    bb_index = (sb_index + 1) % num_players
    
    if my_index == sb_index:
        return "small_blind"
    elif my_index == bb_index:
        return "big_blind"
    else:
        # Calculate position relative to button (who acts last pre-flop)
        # Button is the player before small blind
        button_index = (sb_index - 1) % num_players
        
        # Count positions from button (button = 0, cutoff = 1, etc.)
        positions_from_button = (my_index - button_index) % num_players
        
        if num_players <= 4:
            # In short-handed games, simpler position categories
            if positions_from_button == 0:
                return "late"  # Button
            elif positions_from_button == 1:
                return "middle"  # Cutoff
            else:
                return "early"  # Under the gun or similar
        else:
            # Full ring game (6+ players)
            if positions_from_button == 0:
                return "late"  # Button (best position)
            elif positions_from_button == 1:
                return "late"  # Cutoff (also late position)
            elif positions_from_button <= 3:
                return "middle"  # Middle positions
            else:
                return "early"  # Early positions (worst)