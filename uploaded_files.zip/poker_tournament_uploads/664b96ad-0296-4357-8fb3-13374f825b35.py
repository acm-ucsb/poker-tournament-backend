# <IMPORTS HERE>
import random
# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    pass


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""
# DO NOT MODIFY THE FUNCTION SIGNATURE
def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:

    bet_amount = 0
    call = amount_to_call(state)

    decision = random.randint(1, 100);

    if call == 0:
        if decision < 60:
            bet_amount = 0
        elif decision < 80:
            bet_amount = -1
        else:
            bet_amount = random.randint(min_raise(state), all_in(state))
    else:
        if decision < 30:
            bet_amount = -1
        else:
            bet_amount = call

    return (bet_amount, memory)