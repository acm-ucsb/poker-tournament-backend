# <IMPORTS HERE>
import random
# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>

# EVOLVED PARAMETERS (Generation 2)
LOW_CUTOFF_BASE = 0.5050431377853846
HIGH_CUTOFF_BASE = 0.7
STACK_ADJ_50 = 0.0
STACK_ADJ_30 = 0.05
STACK_ADJ_15 = 0.09876926082466006
STACK_ADJ_0 = 0.15
REASONABLE_CALL_PCT = 0.1
FLOP_SIMS = 300
TURN_SIMS = 200
RIVER_SIMS = 111
EARLY_EXIT_50_HIGH = 0.9076387160218219
EARLY_EXIT_50_LOW = 0.05
EARLY_EXIT_100_HIGH = 0.9
EARLY_EXIT_100_LOW = 0.1
PREFLOP_ADJ_FACTOR = 0.85



""" Store any persistent data for your bot in this class """
class Memory:
    def __init__(self):
        self.starting_stack = None


# Preflop equity table for all 169 starting hands (vs 1 opponent, approximate)
# Format: (rank1, rank2, suited) -> equity
# Ranks: 2=2, 3=3, ..., 10=10, 11=J, 12=Q, 13=K, 14=A
PREFLOP_EQUITY_TABLE = {
    # Pairs (highest to lowest)
    (14, 14): 0.85, (13, 13): 0.82, (12, 12): 0.80, (11, 11): 0.78,
    (10, 10): 0.75, (9, 9): 0.72, (8, 8): 0.69, (7, 7): 0.66,
    (6, 6): 0.63, (5, 5): 0.60, (4, 4): 0.57, (3, 3): 0.54, (2, 2): 0.51,
    
    # Premium suited hands
    (14, 13, True): 0.66, (14, 12, True): 0.66, (14, 11, True): 0.65,
    (14, 10, True): 0.64, (13, 12, True): 0.64, (13, 11, True): 0.63,
    (12, 11, True): 0.62, (14, 9, True): 0.63, (13, 10, True): 0.62,
    
    # Strong suited hands
    (14, 8, True): 0.62, (14, 7, True): 0.61, (14, 6, True): 0.60,
    (14, 5, True): 0.60, (14, 4, True): 0.59, (14, 3, True): 0.59,
    (14, 2, True): 0.58, (13, 9, True): 0.61, (12, 10, True): 0.61,
    (11, 10, True): 0.60, (13, 8, True): 0.60, (12, 9, True): 0.60,
    
    # Medium suited hands
    (13, 7, True): 0.59, (12, 8, True): 0.59, (11, 9, True): 0.59,
    (10, 9, True): 0.58, (13, 6, True): 0.58, (12, 7, True): 0.58,
    (11, 8, True): 0.58, (10, 8, True): 0.57, (9, 8, True): 0.57,
    
    # Premium offsuit hands
    (14, 13, False): 0.65, (14, 12, False): 0.64, (14, 11, False): 0.63,
    (14, 10, False): 0.62, (13, 12, False): 0.62, (13, 11, False): 0.61,
    (12, 11, False): 0.60, (14, 9, False): 0.61, (13, 10, False): 0.60,
    
    # Strong offsuit hands
    (14, 8, False): 0.60, (14, 7, False): 0.59, (14, 6, False): 0.58,
    (14, 5, False): 0.58, (14, 4, False): 0.57, (14, 3, False): 0.57,
    (14, 2, False): 0.56, (13, 9, False): 0.59, (12, 10, False): 0.59,
    (11, 10, False): 0.58, (13, 8, False): 0.58, (12, 9, False): 0.58,
    
    # Medium offsuit hands
    (13, 7, False): 0.57, (12, 8, False): 0.57, (11, 9, False): 0.57,
    (10, 9, False): 0.56, (13, 6, False): 0.56, (12, 7, False): 0.56,
    (11, 8, False): 0.56, (10, 8, False): 0.55, (9, 8, False): 0.55,
}

def normalize_preflop_hand(card1: str, card2: str) -> tuple:
    """
    Normalize a preflop hand to a canonical representation.
    Returns (high_rank, low_rank, is_suited) for non-pairs,
    or (rank, rank) for pairs.
    """
    rank1, suit1 = parse_card(card1)
    rank2, suit2 = parse_card(card2)
    
    if rank1 == rank2:
        # Pair
        return (rank1, rank2)
    else:
        # Non-pair: always put higher rank first
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        is_suited = (suit1 == suit2)
        return (high_rank, low_rank, is_suited)

def get_preflop_equity(hand: list[str], num_opponents: int) -> float:
    """
    Get preflop equity from table, adjusted for number of opponents.
    """
    if len(hand) != 2:
        return 0.5  # Fallback
    
    normalized = normalize_preflop_hand(hand[0], hand[1])
    
    # Look up in table
    base_equity = PREFLOP_EQUITY_TABLE.get(normalized)
    
    if base_equity is None:
        # Not in table - estimate based on hand strength
        rank1, suit1 = parse_card(hand[0])
        rank2, suit2 = parse_card(hand[1])
        
        if rank1 == rank2:
            # Pair not in table - estimate
            base_equity = 0.50 + (rank1 - 7) * 0.03
        else:
            # Non-pair not in table - estimate
            high = max(rank1, rank2)
            low = min(rank1, rank2)
            is_suited = (suit1 == suit2)
            base_equity = 0.45 + (high - 10) * 0.02 + (low - 7) * 0.01
            if is_suited:
                base_equity += 0.02
        base_equity = max(0.20, min(0.90, base_equity))
    
    # Adjust for multiple opponents (equity decreases with more opponents)
    # Approximation: each additional opponent reduces equity
    if num_opponents > 1:
        # Simple model: equity decreases by ~15% per additional opponent
        reduction_factor = PREFLOP_ADJ_FACTOR ** (num_opponents - 1)
        adjusted_equity = 0.30 + (base_equity - 0.30) * reduction_factor
        return max(0.15, min(0.85, adjusted_equity))
    
    return base_equity


def evaluate_hand_for_comparison(hand: list[str], community: list[str]) -> tuple[int, list[int]]:
    """
    Evaluate hand and return (category, tiebreakers) for proper comparison.
    This replicates the internal logic of get_best_hand_from but returns tiebreakers.
    """
    from itertools import combinations
    from collections import Counter
    
    cards = list(hand) + list(community)
    
    def is_straight(ranks: list[int]) -> int:
        if not ranks:
            return 0
        ranks_set = set(ranks)
        for high in range(max(ranks), 4, -1):
            needed = {high - i for i in range(5)}
            if needed.issubset(ranks_set):
                return high
        if {14, 2, 3, 4, 5}.issubset(ranks_set):
            return 5
        return 0
    
    def evaluate_five(cards5: list[str]) -> tuple[int, list[int]]:
        parsed = [parse_card(c) for c in cards5]
        ranks = sorted((r for r, _ in parsed), reverse=True)
        suits = [s for _, s in parsed]
        
        cnt = Counter(ranks)
        counts = sorted(((count, rank) for rank, count in cnt.items()), reverse=True)
        
        is_flush = len(set(suits)) == 1
        unique_ranks_desc = sorted(set(ranks), reverse=True)
        straight_high = is_straight(unique_ranks_desc)
        
        if is_flush and straight_high:
            return (8, [straight_high])
        if counts[0][0] == 4:
            four_rank = counts[0][1]
            kicker = max(r for r in ranks if r != four_rank)
            return (7, [four_rank, kicker])
        if counts[0][0] == 3 and len(counts) > 1 and counts[1][0] >= 2:
            three_rank = counts[0][1]
            pair_rank = counts[1][1]
            return (6, [three_rank, pair_rank])
        if is_flush:
            return (5, ranks)
        if straight_high:
            return (4, [straight_high])
        if counts[0][0] == 3:
            three_rank = counts[0][1]
            kickers = sorted((r for r in ranks if r != three_rank), reverse=True)
            return (3, [three_rank] + kickers)
        if counts[0][0] == 2 and len(counts) > 1 and counts[1][0] == 2:
            high_pair = max(counts[0][1], counts[1][1])
            low_pair = min(counts[0][1], counts[1][1])
            kicker = max(r for r in ranks if r != high_pair and r != low_pair)
            return (2, [high_pair, low_pair, kicker])
        if counts[0][0] == 2:
            pair_rank = counts[0][1]
            kickers = sorted((r for r in ranks if r != pair_rank), reverse=True)
            return (1, [pair_rank] + kickers)
        return (0, ranks)
    
    best = (-1, [])
    for combo in combinations(cards, 5):
        val = evaluate_five(list(combo))
        if val > best:
            best = val
    
    if best[0] < 0:
        return (0, [])
    return best


def calculate_win_probability(state: GameState, num_simulations: int = None) -> float:
    """
    Calculate win probability using preflop table or Monte Carlo simulation.
    
    Args:
        state: Current game state
        num_simulations: Number of simulations to run (None = adaptive)
    
    Returns:
        winProb: Probability of winning (0.0 to 1.0)
    """
    my_index = state.index_to_action
    my_hand = state.player_cards
    community = state.community_cards
    
    # Count active opponents (not folded)
    active_opponents = []
    for i in range(len(state.players)):
        if i != my_index and state.bet_money[i] != -1:
            active_opponents.append(i)
    
    # If no active opponents, we win by default
    if len(active_opponents) == 0:
        return 1.0
    
    num_opponents = len(active_opponents)
    
    # OPTIMIZATION 1: Use preflop equity table when no community cards
    if len(community) == 0:
        return get_preflop_equity(my_hand, num_opponents)
    
    # OPTIMIZATION 2: Adaptive simulation count based on community cards and opponents
    if num_simulations is None:
        if len(community) == 3:  # Flop
            base_sims = FLOP_SIMS
        elif len(community) == 4:  # Turn
            base_sims = TURN_SIMS
        elif len(community) == 5:  # River
            base_sims = RIVER_SIMS
        else:
            base_sims = 500  # Fallback
        
        # Adjust for number of opponents
        if num_opponents == 1:
            num_simulations = base_sims
        elif num_opponents <= 3:
            num_simulations = int(base_sims * 1.5)
        else:
            num_simulations = int(base_sims * 2)
    else:
        num_simulations = num_simulations
    
    # Convert deck back to card strings for easier handling
    all_ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 't', 'j', 'q', 'k', 'a']
    all_suits = ['s', 'd', 'c', 'h']
    
    # Build set of known cards
    known_cards = set()
    for card in my_hand:
        if card:
            known_cards.add(card.lower())
    for card in community:
        if card:
            known_cards.add(card.lower())
    
    # Build remaining deck as card strings
    remaining_cards = []
    for rank in all_ranks:
        for suit in all_suits:
            card_str = rank + suit
            if card_str not in known_cards:
                remaining_cards.append(card_str)
    
    if len(remaining_cards) < len(active_opponents) * 2 + (5 - len(community)):
        # Not enough cards for simulation, use heuristic
        my_category, _ = get_best_hand_from(my_hand, community)
        # Simple heuristic: higher category = higher win prob
        base_prob = (my_category + 1) / 9.0
        # Adjust for number of opponents
        opponent_factor = 1.0 / (len(active_opponents) + 1)
        return base_prob * opponent_factor
    
    wins = 0
    ties = 0
    
    # OPTIMIZATION 3: Early exit for extreme probabilities
    early_exit_threshold_50 = 50  # Check after 50 sims
    early_exit_threshold_100 = 100  # Check after 100 sims
    
    for sim_num in range(num_simulations):
        # Shuffle remaining cards
        sim_deck = remaining_cards.copy()
        random.shuffle(sim_deck)
        
        # Deal opponent hands
        opponent_hands = []
        deck_idx = 0
        for _ in range(len(active_opponents)):
            if deck_idx + 2 <= len(sim_deck):
                opponent_hands.append([sim_deck[deck_idx], sim_deck[deck_idx + 1]])
                deck_idx += 2
            else:
                break
        
        if len(opponent_hands) < len(active_opponents):
            continue
        
        # Deal remaining community cards if needed
        sim_community = community.copy()
        while len(sim_community) < 5 and deck_idx < len(sim_deck):
            sim_community.append(sim_deck[deck_idx])
            deck_idx += 1
        
        if len(sim_community) < 5:
            continue
        
        # Evaluate my hand with tiebreakers
        my_hand_value = evaluate_hand_for_comparison(my_hand, sim_community)
        
        # Evaluate all opponent hands and find best
        best_opponent_value = None
        for opp_hand in opponent_hands:
            opp_hand_value = evaluate_hand_for_comparison(opp_hand, sim_community)
            if best_opponent_value is None or opp_hand_value > best_opponent_value:
                best_opponent_value = opp_hand_value
        
        # Compare hands
        if my_hand_value > best_opponent_value:
            wins += 1
        elif my_hand_value == best_opponent_value:
            ties += 1
        
        # Early exit checks
        completed_sims = sim_num + 1
        if completed_sims == early_exit_threshold_50:
            current_prob = (wins + 0.5 * ties) / completed_sims
            # Exit early if probability is extremely high or low
            if current_prob >= EARLY_EXIT_50_HIGH or current_prob <= EARLY_EXIT_50_LOW:
                return max(0.0, min(1.0, current_prob))
        elif completed_sims == early_exit_threshold_100:
            current_prob = (wins + 0.5 * ties) / completed_sims
            # Exit early if probability is very high or low
            if current_prob >= EARLY_EXIT_100_HIGH or current_prob <= EARLY_EXIT_100_LOW:
                return max(0.0, min(1.0, current_prob))
    
    if num_simulations == 0:
        return 0.5  # Default if no simulations possible
    
    # Win probability: wins + 0.5 * ties (split pot)
    win_prob = (wins + 0.5 * ties) / num_simulations
    return max(0.0, min(1.0, win_prob))


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""
# DO NOT MODIFY THE FUNCTION SIGNATURE
def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    # Initialize memory if needed
    if memory is None:
        memory = Memory()
    
    my_index = state.index_to_action
    stack = state.held_money[my_index]
    
    # Track starting stack (use current stack if not set, assuming it's the first hand)
    if memory.starting_stack is None:
        memory.starting_stack = stack
    
    starting_stack = memory.starting_stack
    
    # Calculate win probability
    win_prob = calculate_win_probability(state)
    
    # Determine if checking is allowed
    call_cost = amount_to_call(state)
    can_check = (call_cost == 0)
    
    # Calculate stack ratio
    if starting_stack > 0:
        stack_ratio = stack / starting_stack
    else:
        stack_ratio = 1.0  # Avoid division by zero
    
    # Calculate threshold adjustment based on stack ratio
    if stack_ratio >= 0.50:
        adjustment = STACK_ADJ_50
    elif stack_ratio >= 0.30:
        adjustment = STACK_ADJ_30
    elif stack_ratio >= 0.15:
        adjustment = STACK_ADJ_15
    else:
        adjustment = STACK_ADJ_0
    
    # Calculate adjusted cutoffs (never below baseline)
    active_players = sum(1 for x in state.bet_money if x != -1)
    num_players = max(active_players, 2)

    # Baseline cutoffs (scale with number of players)
    # 2 players → 50 / 70
    # 3 players → 33 / 53
    # 4 players → 25 / 45
    low_cutoff_base = 1.0 / num_players
    high_cutoff_base = low_cutoff_base + 0.20

    low_cutoff = max(LOW_CUTOFF_BASE + adjustment, LOW_CUTOFF_BASE)
    high_cutoff = max(HIGH_CUTOFF_BASE + adjustment, HIGH_CUTOFF_BASE)
    
    # Decision logic based on win probability tier
    if win_prob < low_cutoff:
        # Low probability range: CHECK if allowed, else FOLD
        if can_check:
            return (0, memory)  # CHECK
        else:
            return (-1, memory)  # FOLD
    
    elif win_prob < high_cutoff:
        # Medium probability range: CHECK if allowed, else CALL if reasonable, else FOLD
        if can_check:
            return (0, memory)  # CHECK
        else:
            reasonable_call = REASONABLE_CALL_PCT * stack
            if call_cost <= reasonable_call:
                return (call_cost, memory)  # CALL
            else:
                return (-1, memory)  # FOLD
    
    else:
        # High probability range: ALWAYS ALL_IN
        all_in_amount = all_in(state)
        return (all_in_amount, memory)  # ALL_IN