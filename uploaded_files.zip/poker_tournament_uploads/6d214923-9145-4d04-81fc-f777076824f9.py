#monolithic file for submission

#equity calculator
#cactus kev hand evaluator implementation
"""
Cactus Kev's Poker Hand Evaluator

A fast, integer-based 5-card poker hand evaluator.
Uses bit manipulation and lookup tables for O(1) evaluation.

Card encoding:
- Cards are represented as 16-bit integers
- Bits 0-3:   rank (0-12, where 0=deuce, 12=ace)
- Bits 4-5:   suit (0-3)
- Bits 6-15:  derived fields for fast evaluation

References:
- http://suffe.cool/poker/evaluator.html
- Hand ranking: straight flush, four of a kind, full house, flush, straight, 
  three of a kind, two pair, pair, high card
"""

# === Card Rank/Suit Constants ===
from enum import Enum


DEUCE = 0
THREE = 1
FOUR = 2
FIVE = 3
SIX = 4
SEVEN = 5
EIGHT = 6
NINE = 7
TEN = 8
JACK = 9
QUEEN = 10
KING = 11
ACE = 12

SPADE = 0
HEART = 1
DIAMOND = 2
CLUB = 3

# Map string representations to rank/suit indices
RANK_MAP = {
    '2': DEUCE, '3': THREE, '4': FOUR, '5': FIVE, '6': SIX,
    '7': SEVEN, '8': EIGHT, '9': NINE, 't': TEN, 'j': JACK,
    'q': QUEEN, 'k': KING, 'a': ACE
}

SUIT_MAP = {'s': SPADE, 'h': HEART, 'd': DIAMOND, 'c': CLUB}

RANK_STR = ['2', '3', '4', '5', '6', '7', '8', '9', 't', 'j', 'q', 'k', 'a']
SUIT_STR = ['s', 'h', 'd', 'c']

# Preflop hand bins for easy preflop calculations
# BW - broadway. Elements of the highest straight

class preflop_bins(Enum):
    PremiumPair = 1 #AA, KK
    HighPair = 2 #QQ, JJ, TT
    MidPair = 3 #99, 88
    NutBWSuited = 4 #AKs, AQs, AJs, KQs
    BWSuited = 5 #ATs, KJs, Qjs, JTs, T9s
    BWOffsuit = 6 #AKo, AQo, AJo, KQo, JTo
    SuitedAceHigh = 7 #Axs (Ax suited, x=6-9)
    SmallPair = 8 #77-22
    SuitedAceLow = 9 #A2s-A5s
    SuitedConnectors = 10 #98s, 87s, 76s, 65s, 54s
    SuitedGappers = 11 #97s, 86s, 75s, 64s, 53s, 43s
    OneHighSuited = 12 #Kxs, Qxs, Jxs (x=2-9)
    TrashOffsuit = 13 #All other offsuit hands


def string_to_card(card_str: str) -> int:
    """
    Convert card string (e.g., '2s', 'As', 'Kd') to integer encoding.
    
    Args:
        card_str: 2-character string [rank][suit]
        
    Returns:
        Integer representation of card (16-bit)
    """
    rank_char = card_str[0].lower()
    suit_char = card_str[1].lower()
    
    if rank_char not in RANK_MAP or suit_char not in SUIT_MAP:
        raise ValueError(f"Invalid card string: {card_str}")
    
    rank = RANK_MAP[rank_char]
    suit = SUIT_MAP[suit_char]
    
    # Encode: bits 0-3=rank, bits 4-5=suit, bits 6-15=derived
    return (rank & 0xF) | ((suit & 0x3) << 4)


def card_to_string(card: int) -> str:
    """Convert integer card encoding back to string representation."""
    rank = card & 0xF
    suit = (card >> 4) & 0x3
    return RANK_STR[rank] + SUIT_STR[suit]


class HandEvaluator:
    """Fast 5-card poker hand evaluator using Cactus Kev algorithm."""
    
    def __init__(self):
        # Precompute lookup tables for fast evaluation
        self._build_tables()
    
    def _build_tables(self):
        """Build lookup tables for hand classification."""
        # Flush check: compute flushes based on suit patterns
        self.flush_table = self._build_flush_table()
        
        # Unique 5-card hand rankings (for non-flush hands)
        self.unique_table = self._build_unique_table()
    
    def _build_flush_table(self) -> dict:
        """Build table mapping rank patterns to flush hand rankings."""
        flush_table = {}
        
        # Generate all possible flush combinations (13 choose 5 = 1287)
        # Represented as 13-bit mask where bit i = 1 if rank i is in hand
        
        for mask in range(1 << 13):
            if bin(mask).count('1') != 5:
                continue
            
            # Extract the 5 ranks
            ranks = [i for i in range(13) if mask & (1 << i)]
            
            # Classify the hand
            rank_value = self._classify_hand(ranks)
            flush_table[mask] = rank_value
        
        return flush_table
    
    def _build_unique_table(self) -> dict:
        """Build table for unique 5-card non-flush hands."""
        unique_table = {}
        
        # For non-flush 5-card hands, create unique representation
        # by XORing rank bits
        for mask in range(1 << 13):
            if bin(mask).count('1') != 5:
                continue
            
            ranks = [i for i in range(13) if mask & (1 << i)]
            rank_value = self._classify_hand(ranks)
            
            # Use XOR of ranks as a key for quick lookup
            key = 0
            for rank in ranks:
                key ^= (1 << rank)
            
            unique_table[key] = rank_value
        
        return unique_table
    
    def _classify_hand(self, ranks: list) -> int:
        """
        Classify a 5-card hand by pairs/trips/quads (no straights/flushes).
        
        Ranking order (best to worst):
        - Four of a kind: 1000-1191
        - Full house: 1200-1391
        - Three of a kind: 2000-2215
        - Two pair: 3000-3255
        - Pair: 4000-6047
        - High card: 6200+
        
        Args:
            ranks: List of 5 rank indices (0-12)
            
        Returns:
            Integer ranking (lower is better)
        """
        ranks_sorted = sorted(ranks, reverse=True)
        
        # Count rank frequencies
        from collections import Counter
        freq = Counter(ranks_sorted)
        counts = sorted(freq.values(), reverse=True)
        
        if counts == [4, 1]:
            # Four of a kind
            quad_rank = [r for r in ranks_sorted if ranks.count(r) == 4][0]
            return 1000 + (12 - quad_rank)  # Aces highest
        elif counts == [3, 2]:
            # Full house
            trip_rank = [r for r in ranks_sorted if ranks.count(r) == 3][0]
            pair_rank = [r for r in ranks_sorted if ranks.count(r) == 2][0]
            return 1200 + (12 - trip_rank) * 13 + (12 - pair_rank)
        elif counts == [3, 1, 1]:
            # Three of a kind - encode kickers
            trip_rank = [r for r in ranks_sorted if ranks.count(r) == 3][0]
            kickers = sorted([r for r in ranks if ranks.count(r) == 1], reverse=True)
            kicker_value = sum((13 - k) * (100 >> (i * 2)) for i, k in enumerate(kickers[:2]))
            return 2000 + (12 - trip_rank) * 100 + kicker_value
        elif counts == [2, 2, 1]:
            # Two pair - encode both pairs and kicker
            pairs = sorted([r for r in ranks_sorted if ranks.count(r) == 2], reverse=True)
            kicker = [r for r in ranks if ranks.count(r) == 1][0]
            return 3000 + (12 - pairs[0]) * 100 + (12 - pairs[1]) * 10 + (12 - kicker)
        elif counts == [2, 1, 1, 1]:
            # One pair - need to encode kickers too
            pair_rank = [r for r in ranks_sorted if ranks.count(r) == 2][0]
            kickers = sorted([r for r in ranks if ranks.count(r) == 1], reverse=True)
            # Encode: base + pair_rank*1000 + kicker values
            kicker_value = sum((13 - k) * (100 >> (i * 2)) for i, k in enumerate(kickers[:3]))
            return 4000 + (12 - pair_rank) * 1000 + kicker_value
        else:
            # High card - kicker order matters
            high_card = ranks_sorted[0]
            return 6200 + (12 - high_card) * 1000 + sum(12 - r for r in ranks_sorted[1:])
    
    def _is_straight(self, ranks: list) -> bool:
        """Check if 5 ranks form a straight."""
        if len(ranks) != 5:
            return False
        
        sorted_ranks = sorted(set(ranks))
        
        # Normal straight
        if sorted_ranks[-1] - sorted_ranks[0] == 4 and len(set(ranks)) == 5:
            return True
        
        # Wheel straight (A-2-3-4-5)
        if set(sorted_ranks) == {0, 1, 2, 3, 12}:
            return True
        
        return False
    
    def evaluate_5cards(self, cards: list) -> int:
        """
        Evaluate a 5-card poker hand.
        
        Args:
            cards: List of 5 card integers or card strings
            
        Returns:
            Hand ranking (lower = better hand)
        """
        if len(cards) != 5:
            raise ValueError(f"Expected 5 cards, got {len(cards)}")
        
        # Convert strings to integers if needed
        card_ints = []
        for card in cards:
            if isinstance(card, str):
                card_ints.append(string_to_card(card))
            else:
                card_ints.append(card)
        
        return self._evaluate(card_ints)
    
    def evaluate_7cards(self, cards: list) -> int:
        """
        Evaluate the best 5-card hand from 7 cards.
        
        Args:
            cards: List of 7 card integers or card strings
            
        Returns:
            Hand ranking of the best 5-card hand (lower = better)
        """
        if len(cards) != 7:
            raise ValueError(f"Expected 7 cards, got {len(cards)}")
        
        # Convert strings to integers if needed
        card_ints = []
        for card in cards:
            if isinstance(card, str):
                card_ints.append(string_to_card(card))
            else:
                card_ints.append(card)
        
        # Try all combinations of 5 cards from 7
        from itertools import combinations
        best_rank = float('inf')
        
        for combo in combinations(card_ints, 5):
            rank = self._evaluate(list(combo))
            best_rank = min(best_rank, rank)
        
        return best_rank
    
    def _evaluate(self, card_ints: list) -> int:
        """Internal evaluation of exactly 5 cards."""
        # Extract suits and ranks
        suits = [(card >> 4) & 0x3 for card in card_ints]
        ranks = [card & 0xF for card in card_ints]
        
        # Check if all cards have same suit (flush)
        is_flush = len(set(suits)) == 1
        
        # Check for straight
        ranks_sorted = sorted(ranks, reverse=True)
        is_straight = self._is_straight(ranks_sorted)
        
        if is_flush and is_straight:
            # Straight flush - best possible hands (0-823)
            high_rank = max(ranks)
            if set(ranks) == {0, 1, 2, 3, 12}:  # A-2-3-4-5
                return 1  # Wheel straight flush (lowest rank)
            return (12 - high_rank)  # Royal flush = 0, then increasing
        elif is_flush:
            # Regular flush (not straight) - 1400-2215
            ranks_sorted = sorted(ranks, reverse=True)
            high_card = ranks_sorted[0]
            return 1400 + (12 - high_card) * 1000 + sum(12 - r for r in ranks_sorted[1:])
        elif is_straight:
            # Straight (not a flush) - 1600-2399 (between flush and three-of-a-kind)
            high_rank = ranks_sorted[0]
            if set(ranks) == {0, 1, 2, 3, 12}:  # A-2-3-4-5
                return 1600 + 799  # Wheel is lowest straight
            return 1600 + (12 - high_rank)  # Higher card = lower value (better)
        else:
            # Non-flush, non-straight: classify by pairs
            return self._classify_hand(ranks)


# Global evaluator instance
_evaluator = HandEvaluator()


def evaluate_hand(cards: list) -> int:
    """
    Evaluate a 5-card poker hand.
    
    Args:
        cards: List of 5 cards (can be strings like '2s', 'As', etc. or integers)
        
    Returns:
        Integer hand ranking (lower = better hand)
    """
    return _evaluator.evaluate_5cards(cards)


def evaluate_best_hand(cards: list) -> int:
    """
    Evaluate the best 5-card hand from 7 cards (Texas Hold'em).
    
    Args:
        cards: List of 7 cards (can be strings or integers)
        
    Returns:
        Integer hand ranking of best 5-card hand (lower = better)
    """
    return _evaluator.evaluate_7cards(cards)

def bin_preflop_hand(cards: list) -> preflop_bins:
    """
    Bin preflop hand into categories based on rank and suitedness.
    
    Args:
        cards: List of 2 cards (can be strings or integers)

    Returns:
        Integer bin index representing hand category
    """
    if not isinstance(cards, list) or len(cards) != 2:
        raise ValueError("cards must be a list of exactly 2 cards")

    # Convert to integer card encoding if needed
    c0 = string_to_card(cards[0]) if isinstance(cards[0], str) else cards[0]
    c1 = string_to_card(cards[1]) if isinstance(cards[1], str) else cards[1]

    r0 = c0 & 0xF
    r1 = c1 & 0xF
    s0 = (c0 >> 4) & 0x3
    s1 = (c1 >> 4) & 0x3

    # Normalize ordering: high_rank is the higher card rank
    high = max(r0, r1)
    low = min(r0, r1)
    suited = (s0 == s1)

    # Pair categories
    if high == low:
        if high in (ACE, KING):
            return preflop_bins.PremiumPair
        if high in (QUEEN, JACK, TEN):
            return preflop_bins.HighPair
        if high in (NINE, EIGHT):
            return preflop_bins.MidPair
        return preflop_bins.SmallPair

    # Helper to check unordered rank pair
    def ranks_are(a, b):
        return (high == a and low == b) or (high == b and low == a)

    # Suited hands
    if suited:
        # Nut broadway suited (AKs, AQs, AJs, KQs)
        if ranks_are(ACE, KING) or ranks_are(ACE, QUEEN) or ranks_are(ACE, JACK) or ranks_are(KING, QUEEN):
            return preflop_bins.NutBWSuited

        # Broadways suited (ATs, KJs, QJs, JTs, T9s)
        if ranks_are(ACE, TEN) or ranks_are(KING, JACK) or ranks_are(QUEEN, JACK) or ranks_are(JACK, TEN) or ranks_are(TEN, NINE):
            return preflop_bins.BWSuited

        # Suited ace low (A2s-A5s)
        if high == ACE and low <= FIVE:
            return preflop_bins.SuitedAceLow

        # Suited ace high (A6s-A9s)
        if high == ACE and FIVE < low <= NINE:
            return preflop_bins.SuitedAceHigh

        # Suited connectors (98s, 87s, 76s, 65s, 54s)
        if abs(high - low) == 1 and low >= FOUR and high <= NINE:
            return preflop_bins.SuitedConnectors

        # Suited one-gap (97s, 86s, 75s, 64s, 53s, 43s)
        if abs(high - low) == 2 and low >= THREE:
            return preflop_bins.SuitedGappers

        # One high suited (Kxs, Qxs, Jxs where x is low)
        if high in (KING, QUEEN, JACK):
            return preflop_bins.OneHighSuited

        # Fallback for other suited hands
        return preflop_bins.OneHighSuited

    # Offsuit hands
    # Broadways offsuit (AKo, AQo, AJo, KQo, JTo)
    if ranks_are(ACE, KING) or ranks_are(ACE, QUEEN) or ranks_are(ACE, JACK) or ranks_are(KING, QUEEN) or ranks_are(JACK, TEN):
        return preflop_bins.BWOffsuit

    # Everything else offsuit is considered trash for now
    return preflop_bins.TrashOffsuit

# === Hand rank classification helpers ===
def hand_rank_name(rank: int) -> str:
    """Get human-readable name for hand rank."""
    if rank < 1000:
        if rank >= 4096:
            return "Straight"
        elif rank >= 2048:
            if rank >= 3072:
                return "Four of a Kind"
            elif rank >= 2560:
                return "Full House"
            elif rank >= 2560:
                return "Flush"
            elif rank >= 2304:
                return "Three of a Kind"
            elif rank >= 2176:
                return "Two Pair"
            elif rank >= 2144:
                return "Pair"
            else:
                return "High Card"
    else:
        return "Flush"

# equity calculator
from itertools import combinations
# from hand_eval import evaluate_hand, evaluate_best_hand
import random

#simpler function, for more widespread use
def estimate_equity(hero_hole: list[str], villain_range: list[str], num_opps: int, community_hand: list[str], num_sims: int):
    wins = 0.0
    ties = 0.0
    hero_best_rank = 100000

    # Find best possible hand for hero
    for hand in combinations(hero_hole + community_hand, 5):
        hero_rank = evaluate_hand(hand)
        if hero_rank < hero_best_rank:
            hero_best_rank = hero_rank

    # Run Monte Carlo simulations: randomly sample opponent hands
    for _ in range(num_sims):
        best_opponent_rank = 100000
        
        # For each opponent, randomly sample 2 hole cards from villain range
        for _ in range(num_opps):
            # Sample opponent hole cards from the villain range
            if len(villain_range) >= 2:
                sampled_hole = random.sample(villain_range, 2)
            else:
                sampled_hole = villain_range
            
            # Find best 5-card hand for this opponent
            for hand in combinations(sampled_hole + community_hand, 5):
                opponent_rank = evaluate_hand(hand)
                if opponent_rank < best_opponent_rank:
                    best_opponent_rank = opponent_rank
        
        if hero_best_rank < best_opponent_rank:
            wins += 1
        elif hero_best_rank == best_opponent_rank:
            ties += 1
    
    # Equity = (wins + 0.5 * ties) / num_sims
    # This ensures ties split the equity equally regardless of num_opps
    return (wins + (0.5 * ties)) / num_opps / num_sims if villain_range else 0


#opp eval:
# ultra_light_aggression.py
# Pure Python, no external libs. One estimator instance per opponent.

import math

def _sigmoid(x, k=6.0):
    # Stable sigmoid in (0,1)
    return 1.0 / (1.0 + math.exp(-k * x))

class OpponentAggressionEstimator:
    """
    Tracks simple EWMAs and returns an aggression score in [0,1].
    Call update(bet_ratio, stack_bb) for each meaningful action where villain bets/raises (or call with ratio=0).
    """
    def __init__(self,
                 ewma_alpha=0.15,
                 big_bet_threshold=0.5,
                 w_avg=1.0,
                 w_big=1.2,
                 w_stack=-0.6,
                 sigmoid_k=6.0,
                 init_avg=0.15,
                 init_big_rate=0.05):
        # EWMA state
        self.ewma_alpha = ewma_alpha
        self.avg_bet_ratio = init_avg      # EWMA of bet / pot
        self.big_bet_rate = init_big_rate  # EWMA of (bet_ratio >= threshold)
        self.big_bet_threshold = big_bet_threshold

        # combination weights
        self.w_avg = w_avg
        self.w_big = w_big
        self.w_stack = w_stack
        self.sigmoid_k = sigmoid_k

        # counters (optional) to detect cold-start
        self.t = 0

    def update(self, bet_ratio, stack_bb):
        """
        Update EWMA stats for one observed bet action.
        bet_ratio: bet_size / pot_size (0 if check/call/no-bet)
        stack_bb: opponent effective stack in BB at that moment (float)
        Returns: aggression score in [0,1]
        """
        a = self.ewma_alpha
        # update avg bet ratio EWMA
        self.avg_bet_ratio = (1 - a) * self.avg_bet_ratio + a * bet_ratio

        # update big bet rate EWMA
        big_flag = 1.0 if bet_ratio >= self.big_bet_threshold else 0.0
        self.big_bet_rate = (1 - a) * self.big_bet_rate + a * big_flag

        self.t += 1

        return self.aggression_score(stack_bb)

    def aggression_score(self, stack_bb):
        """
        Compute aggression score in [0,1] from current EWMAs and stack.
        stack_bb: effective stack in BB
        """
        # normalize stack to [0,1] where 0=very small (~5bb), 1=very large (>=200bb).
        # adjust min/max to taste.
        min_stack, max_stack = 5.0, 200.0
        s = max(min(stack_bb, max_stack), min_stack)
        stack_norm = (s - min_stack) / (max_stack - min_stack)  # in [0,1]

        # feature vector (you can add more features if you want)
        x_avg = self.avg_bet_ratio     # expected 0..~2 (but usually <1)
        x_big = self.big_bet_rate      # 0..1
        x_stack = stack_norm           # 0..1

        # optionally scale x_avg to [0,1] by dividing by a reasonable cap (e.g., 1.0)
        x_avg_clipped = min(x_avg, 2.0) / 2.0   # now in [0,1] (cap to keep stability)

        # linear score
        linear = (self.w_avg * x_avg_clipped) + (self.w_big * x_big) + (self.w_stack * x_stack - 0.0)
        # apply sigmoid to squash to [0,1]
        agg = _sigmoid(linear, k=self.sigmoid_k)
        return agg

    # convenience: map aggression to range multiplier (how much wider the villain range)
    def range_multiplier(self, aggression, low=0.7, high=1.6):
        """
        Maps aggression∈[0,1] to multiplier in [low,high].
        Aggression=0 -> multiplier low (tighter range)
        Aggression=1 -> multiplier high (wider range)
        """
        return low + (high - low) * aggression

    # convenience: approximate adjusted equity against widened/tightened range
    def adjusted_equity(self, raw_equity, aggression, beta=0.9):
        """
        A light approximation: shrink equity when villain range widens.
        raw_equity: your equity vs baseline range (0..1)
        aggression: 0..1
        beta: exponent control (0<beta<=1). beta<1 makes effect milder.
        Formula: adj = raw_equity / (range_mult ** beta)
        """
        r = self.range_multiplier(aggression)
        adj = raw_equity / (r ** beta)
        # clamp to [0,1]
        adj = max(0.0, min(1.0, adj))
        return adj

#bot:
# <IMPORTS HERE>
from enum import Enum
from typing import TypedDict
# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>

#====================== Preflop =============================== 
#calculate position based on number 
#of players and index of small blind,
#index to action.
class Preflop_Position(Enum): #value given by index from the sb.
    SB = 0
    BB = 1
    UTG = 2
    MP = 3
    CO = 4
    BTN = 5

class Position(Enum):
    SB = 0
    BB = 1
    BTN = 2
    OTHER = 3

class OpponentBet:
    bet: int
    pot: int
    stack_bb: float
    bet_ratio: float

    def __init__(bet: int, pot: int, stack_bb: float):
        bet = bet
        pot = pot
        stack_bb = stack_bb
        bet_ratio = bet / pot

class OpponentStatMap(TypedDict):
    id: list[OpponentBet]

#always with 6 players
def get_preflop_position(state: GameState) -> Preflop_Position:
    player_index = state.index_to_action
    sb_index = state.index_of_small_blind
    clockwise_distance: int = 0

    relative_index = player_index - sb_index
    if relative_index < 0: #player behind sb, so add distance
        clockwise_distance = player_index + (6 - sb_index)
    else:
        clockwise_distance = player_index - sb_index
        
    return Preflop_Position(clockwise_distance)

#========================Post-flop==========================
def get_postflop_position(state: GameState) -> Position:
    player_index = state.index_to_action
    num_players = len(state.players)
    sb_index = state.index_of_small_blind
    clockwise_distance: int = 0

    relative_index = player_index - sb_index
    if relative_index < 0: #player behind sb, so add distance
        clockwise_distance = player_index + (num_players - sb_index)
    else:
        clockwise_distance = player_index - sb_index

    if clockwise_distance == num_players:
        return Position.BTN
    elif clockwise_distance <= num_players - 1:
        if clockwise_distance <= num_players - num_players - 1:
            return Position.BB
        elif clockwise_distance == 0:
            return Position.SB
        return Position.OTHER
        
    return Position.OTHER

RANKS = ['2','3','4','5','6','7','8','9','T','J','Q','K','A']
SUITS = ['s','h','d','c']

def full_deck() -> list[str]:
    """Return full 52-card deck as strings like 'As','Td' (rank+suit)."""
    return [r + s for r in RANKS for s in SUITS]

def _normalize_card_list(cards: list[str]) -> set:
    """Helper to normalize and return set for fast membership checks."""
    return set(cards) if cards else set()

def build_villain_range(scalar: float,
                        hero_hole: list[str],
                        community_cards: list[str],
                        pot_bb: float | None = None,
                        min_cards: int = 2,
                        treat_scalar_as_multiplier: bool = False) -> list[str]:
    """
    Build a villain range list (contiguous subarray of the deck) whose length is determined by:
        length = int(round(10 * scalar))  (or base_len * scalar if treat_scalar_as_multiplier=True)

    Additionally, choose the START index of that contiguous window according to:
      - aggression-like scalar (0..1): low -> conservative, high -> aggressive
      - pot_bb: normalized pot size (higher pot -> stronger shift behavior)

    Args:
        scalar: aggression-like scalar (0..1) OR a multiplier if treat_scalar_as_multiplier True.
        hero_hole: hero's hole cards to remove from the deck
        community_cards: community cards to remove from the deck
        pot_bb: pot size in big blinds (float). If None, we assume small pot (no large shift).
        min_cards: minimum number of cards to include in range (>=2)
        treat_scalar_as_multiplier: if True, treat `scalar` as a multiplier on base_len=10
                                    (useful if you pass a range_multiplier like 0.7..1.6)
    Returns:
        list[str]: contiguous villain_range from the filtered deck
    """
    deck = full_deck()
    removed = _normalize_card_list(hero_hole) | _normalize_card_list(community_cards)
    deck_filtered = [c for c in deck if c not in removed]

    # Determine target length
    if treat_scalar_as_multiplier:
        base_len = 10
        raw_len = int(round(base_len * float(scalar)))
    else:
        raw_len = int(round(10.0 * float(scalar)))

    length = max(min_cards, min(len(deck_filtered), raw_len))

    # If length would consume entire deck, just return deck_filtered
    if length >= len(deck_filtered):
        return list(deck_filtered)

    # Normalize pot_bb into [0,1] (0 => tiny pot, 1 => very large pot)
    if pot_bb is None:
        pot_norm = 0.0
    else:
        # tune these caps to taste: consider pots up to 200 BB as "very large"
        pot_cap = 200.0
        pot_norm = max(0.0, min(1.0, pot_bb / pot_cap))

    # Interpret scalar as aggression in [0,1] when not treat_scalar_as_multiplier.
    # If treat_scalar_as_multiplier, derive an aggression proxy by mapping multiplier to [0,1].
    if treat_scalar_as_multiplier:
        # assume typical multipliers lie in ~[0.5,2.0]; map that to [0,1] with clamping
        mul = float(scalar)
        # choose sensible mapping parameters (tune if needed)
        mul_min, mul_max = 0.5, 2.0
        agg = (mul - mul_min) / (mul_max - mul_min)
        agg = max(0.0, min(1.0, agg))
    else:
        agg = max(0.0, min(1.0, float(scalar)))

    # Compute start fraction (0 => start of deck_filtered; 1 => farthest possible start)
    # Desired behavior:
    #  - If pot small (pot_norm~0) -> start_frac ~ 0 (little shift)
    #  - If pot large (pot_norm~1):
    #       conservative (agg=0) -> start_frac ~ 0.9 (near high cards)
    #       aggressive  (agg=1) -> start_frac ~ 0.5 (middle)
    #
    # We combine these with a simple convex blend:
    conservative_frac = 0.9  # where conservative should point when pot is maxed
    aggressive_frac = 0.5   # where aggressive should point when pot is maxed
    # start_frac ranges [0..1] scaled by pot_norm
    start_frac = pot_norm * ((1.0 - agg) * conservative_frac + agg * aggressive_frac)

    # Convert start_frac to a start index that ensures window fits in deck_filtered
    max_start = len(deck_filtered) - length
    start_index = int(round(start_frac * max_start))
    # clamp
    start_index = max(0, min(max_start, start_index))

    if (start_index + length > len(deck_filtered)):
        return deck_filtered[start_index:]
    else:
        # Return the contiguous window
        villain_range = deck_filtered[start_index : start_index + length]
    return villain_range


""" Store any persistent data for your bot in this class """
class Memory:
    """
    Persistent per-game data. We keep:
      - villain_aggro_map: player_id -> OpponentAggressionEstimator instance
      - villain_last_bet: player_id -> last observed bet_money (int)
    """
    def __init__(self):
        # map player id -> OpponentAggressionEstimator
        self.villain_aggro_map: dict[str, OpponentAggressionEstimator] = {}
        # map player id -> last observed bet_money (int)
        self.villain_last_bet: dict[str, int] = {}
        # optional: population-level default aggression to blend during cold-start
        self.population_avg_aggression: float = 0.15


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""

def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    #first round of the game
    if memory is None:
        memory = Memory()

    if (get_round_name == "Pre-Flop"):
        bb: int = state.big_blind
        bet: int = 0

        # preflop_hand: preflop_bins

        preflop_hand = bin_preflop_hand(state.player_cards)

        if get_preflop_position(state=state) == Preflop_Position.SB: #play if small blind in first round.
            return (state.small_blind, memory)
        if get_preflop_position(state=state) == Preflop_Position.BB:
            return (bb, memory)
        
        if preflop_hand > preflop_bins.OneHighSuited:
            return (fold(), memory)
        elif preflop_hand <= preflop_bins.OneHighSuited and preflop_hand > preflop_bins.SuitedAceLow:
            if amount_to_call(state=state) > bb:
                return (fold(), memory)
            return (call(), memory) # limp through
        elif preflop_hand <= preflop_bins.SuitedAceLow and preflop_hand > preflop_bins.BWSuited:
            return (call(), memory) #open to playing
        else: #call everything. Don't preflop raise.
            bet = (1.5 + (1.0/preflop_hand)) * min_raise(state) 
            return (bet, memory)

    # any other round: 
    # mvp:
    # based on position in round, info on villains (bet size), calculate villain range
    #villain range is the full array of cards (52), and we select a subarray of length depending on the calculated scalar. 
    # among several hands (select cards, etc...)
    # then estimate equity of hand against them and bet / fold accordingly
    # Even on weak equity, do not fold on the flop unless another bot bets. 
    # with some randomness (i.e. 1/5 of the time we would fold go fishing on the river)
    pos: Position = get_postflop_position(state=state)
    est = OpponentAggressionEstimator()

    #if first after flop, just play on equity. 
    #if not, play off of info given.

    #map villains to aggressive / conservative based off current, past bets
    main_pot_value = state.pots[0].value if state.pots else 1
    big_blind = state.big_blind if state.big_blind > 0 else 1

    # iterate through players (max 6) but only update estimators for players whose bet_money changed
    for i, player_id in enumerate(state.players):
        try:
            curr_bet = int(state.bet_money[i])
        except Exception:
            curr_bet = 0

        last_bet = memory.villain_last_bet.get(player_id, None)

        # create estimator lazily if first time we see this player
        if player_id not in memory.villain_aggro_map:
            memory.villain_aggro_map[player_id] = OpponentAggressionEstimator()

        # If this is the first time we see them, initialize last_bet but do not necessarily treat it as an action
        if last_bet is None:
            memory.villain_last_bet[player_id] = curr_bet
            # Optionally: if curr_bet > 0 consider it an observed action and update estimator:
            if curr_bet > 0:
                bet_ratio = (curr_bet / main_pot_value) if main_pot_value > 0 else 0.0
                stack_bb = (state.held_money[i] / big_blind) if big_blind > 0 else 0.0
                memory.villain_aggro_map[player_id].update(bet_ratio=bet_ratio, stack_bb=stack_bb)
            continue

        # Update only when the bet amount for that player changed since last turn (they acted)
        if curr_bet != last_bet:
            # compute bet_ratio relative to pot (guard division)
            bet_ratio = (curr_bet / main_pot_value) if main_pot_value > 0 else 0.0
            stack_bb = (state.held_money[i] / big_blind) if big_blind > 0 else 0.0

            # update the estimator in-place
            memory.villain_aggro_map[player_id].update(bet_ratio=bet_ratio, stack_bb=stack_bb)

            # store the new last_bet
            memory.villain_last_bet[player_id] = curr_bet
    

    players_in_pot = [(i, state.players[i]) for i, m in enumerate(state.bet_money) if m > 0]
    # collect aggressions:

    villain_aggs = {}
    for (i, player) in players_in_pot:
        est = memory.villain_aggro_map.get(player)
        stack_bb = (state.held_money[i] / big_blind) if big_blind > 0 else 0.0
        agg = est.aggression_score(stack_bb)
        villain_aggs[player_id] = agg

    #villain range is the full array of cards (52), and we select 
    #a subarray of length 10 * calculated scalar. 
    
    #remove hero from pot.
    players_in_pot.remove((state.index_to_action, state.players[i]))
    try:
        hero_hole = state.player_cards  # adjust if your hero index differs
    except Exception:
        hero_hole = []

    # collect community cards
    community = state.community_cards if hasattr(state, 'community_cards') else []

    # aggregator: mean aggression among opponents in pot (exclude hero if present)
    agg_values = []
    for (_, pid) in players_in_pot:
        # ensure we don't include hero; if your hero id is a known string, filter it out here.
        if pid in memory.villain_aggro_map:
            # find index for pid to get stack. If not found, default stack
            try:
                idx = state.players.index(pid)
                stack_bb = (state.held_money[idx] / state.big_blind) if state.big_blind > 0 else 0.0
            except ValueError:
                stack_bb = 0.0
            agg_values.append(memory.villain_aggro_map[pid].aggression_score(stack_bb))
    # fallback if no opponents found
    if len(agg_values) == 0:
        avg_agg = 0.15
    else:
        avg_agg = sum(agg_values) / len(agg_values)

    # Build villain_range: treat_scalar_as_multiplier=False assumes avg_agg in [0,1]
    villain_range = build_villain_range(avg_agg, hero_hole, community, min_cards=2, treat_scalar_as_multiplier=False)

    # Choose number of sims (tradeoff speed vs accuracy)
    num_sims = 300  # lower if you need speed; raise for accuracy

    # Call your provided Monte Carlo equity estimator.
    # Note: your estimator expects hero_hole (list[str]), villain_range (list[str]), num_opps (int), community_hand, num_sims
    equity = estimate_equity(hero_hole=hero_hole,
                            villain_range=villain_range,
                            num_opps=max(1, len(players_in_pot)),
                            community_hand=community,
                            num_sims=num_sims)
        
    if equity >= 0.8:
        return (all_in(state=state), memory)
    elif equity >= 0.65:
        if (is_valid_bet(state=state, amount = int(round( (1+equity) * min_raise(state=state))))):
            return (int(round( (1+equity) * min_raise(state=state))), memory)
        elif (is_valid_bet(state=state, amount=amount_to_call)):
            return (call(state=state), memory)
        else:
            return (fold(), memory)
    elif equity >= 0.5:
        if (is_valid_bet(state=state, amount=amount_to_call)):
            return (call(state=state), memory)
        else:
            return (fold(), memory)
    elif equity >= 0.3:
        if (is_valid_bet(state=state, amount=check())):
            return (check(), memory)
        else:
            return (fold(), memory)
    else:
        if (get_round_name(state=state) == "Flop"):
            return (check(), memory)
        return (fold(), memory)

#bet strategy:
'''
1. calculate hand equity
2. based on equity and pot odds, decide on preflop action
3. then, use existing equity + classification model of opponents to determine postflop actions
4. adjust bet based on risk analysis and opponent classification.
    ^ use this to adjust input ranges on monte carlo sims in equity func.
    (e.g., if opponent is "tight", assume narrower range of hands / lower pot value)

5. implement bluffing strategy based on game dynamics and opponent tendencies.
    e.g., bluff against "tight" players, call "aggressive" players, etc...
6. continuously update opponent models based on observed behavior (throughout the game).


7. refine betting strategy using reinforcement learning techniques over multiple games 
(train analysis biases throughout weekend)?
linear regression / predictive model based on hands, types of opponents in pot
use that to adjust bet sizing and bluff frequency. 

    
'''