# <IMPORTS HERE>
from typing import Optional
import random

# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    def __init__(self):
        self.no_fold = False
    





""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""
# DO NOT MODIFY THE FUNCTION SIGNATURE
def bet(state: GameState, memory: Optional[Memory]=None) -> tuple[int, Optional[Memory]]:
    # Initialize memory if None
    if memory is None:
        memory = Memory()

    my_cards = state.player_cards
    
    has_ace = False
    has_pair = False
    bet_amount = 0
    
    if len(my_cards) >= 1:
        ranks = []
        for card in my_cards:
            rank, _ = parse_card(card)
            ranks.append(rank)
            if rank == 14:
                has_ace = True
        
        if len(ranks) >= 2 and ranks[0] == ranks[1]:
            has_pair = True
    
    if has_ace or has_pair:
        if has_ace and random.randint(0,3) != 0:
            bet_amount = all_in(state)
        else:
            bet_amount = 0
        if has_pair:
            bet_amount = all_in(state)
    else:
        if random.randint(0,4) == 0:
            bet_amount = all_in(state) 
        else:
            bet_amount = 0  

    if memory.no_fold == True:
        bet_amount = all_in(state)
        memory.no_fold = False
    else:
        if bet_amount > 0:
            if random.randint(0,3) != 0:
                bet_amount = bet_amount - 200
                memory.no_fold = True
            else:
                bet_amount = all_in(state)

    
    return (bet_amount, memory)