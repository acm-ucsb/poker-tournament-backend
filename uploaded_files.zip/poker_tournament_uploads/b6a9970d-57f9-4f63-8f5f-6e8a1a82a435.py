# <IMPORTS HERE>

# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    last_opponent_action: int = 0


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""
# DO NOT MODIFY THE FUNCTION SIGNATURE
def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    if memory is None:
        memory = Memory()
        
    # Pre-Flop: always call
    if(get_round_name(state) == "Pre-Flop"):
        return call(state), memory
    
    # Check opponent's current bet in this betting round
    opponent_index = (state.index_to_action - 1) % len(state.players)
    opponent_current_bet = state.bet_money[opponent_index]
    
    # Store it in memory for reference
    memory.last_opponent_action = opponent_current_bet
    
    # If opponent checked (bet is 0), do min_raise
    if(opponent_current_bet == 0):
        return min_raise(state), memory
    
    # If opponent raised (bet > 0), fold
    return fold(), memory
