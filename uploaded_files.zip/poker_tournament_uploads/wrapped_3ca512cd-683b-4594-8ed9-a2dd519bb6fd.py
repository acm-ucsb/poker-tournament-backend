import pickle
import sys
import os

# class Pot:
#     value: int
#     players: list[str]


# class GameState:
#     index_to_action: int
#     index_of_small_blind: int
#     players: list[str]
#     player_cards: list[str]
#     held_money: list[int]
#     bet_money: list[int]
#     community_cards: list[str]
#     pots: list[Pot]
#     small_blind: int
#     big_blind: int

# class Memory:
#     pass

# ======================= #
# ACTUAL BOT CODE HERE!!! #
# ======================= #
# <IMPORTS HERE>
import math
# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    pass


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""

def get_cards_in_hand(player_cards, best_cards):
    count = 0
    player_set = set(player_cards)
    for card in best_cards:
        if card in player_set:
            count += 1
    return count

def get_one_away(hand: list[str], community: list[str]) -> tuple[int, list[str]]:
    """
    Return the highest-ranking poker hand we are exactly ONE card away from completing,
    and the subset of cards contributing to that near-hand.
    
    Returns:
        (category, cards_involved)
        category: 0..8 (same scale you provided)
    """

    from collections import Counter

    cards = hand + community
    if not cards:
        return (0, [])

    # Parse cards into ranks + suits
    def parse(c):
        rank_map = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,
                    't':10,'j':11,'q':12,'k':13,'a':14}
        r = rank_map[c[0].lower()]
        s = c[1].lower()
        return r, s

    parsed = [parse(c) for c in cards]
    ranks = [r for r, _ in parsed]
    suits = [s for _, s in parsed]

    rank_count = Counter(ranks)
    suit_count = Counter(suits)

    # ---------- POSSIBILITIES WE ARE ONE CARD AWAY FROM ----------

    # --- 8: Straight Flush ---
    best_sf = []
    for suit in suit_count:
        suited_cards = [r for (r, s) in parsed if s == suit]
        if len(suited_cards) >= 4:
            uniq = sorted(set(suited_cards))

            # Check straight patterns
            for low in range(2, 11):
                window = {low+i for i in range(5)}
                have = window & set(uniq)
                if len(have) == 4:
                    best_sf = [c for c in cards if parse(c)[0] in have and parse(c)[1] == suit]
                    return (8, best_sf)

            # Wheel straight A-5
            wheel = {14, 2, 3, 4, 5}
            if len(wheel & set(uniq)) == 4:
                best_sf = [c for c in cards if parse(c)[0] in wheel and parse(c)[1] == suit]
                return (8, best_sf)

    # --- 7: Four of a Kind ---
    for r, count in rank_count.items():
        if count == 3:
            near = [c for c in cards if parse(c)[0] == r]
            return (7, near)

    # --- 6: Full House ---
    trips = [r for r, c in rank_count.items() if c == 3]
    pairs = [r for r, c in rank_count.items() if c == 2]

    # Trips + anything → one away from full house
    if trips and (len(rank_count) > 1):
        involved = [c for c in cards if parse(c)[0] in trips + pairs]
        return (6, involved)

    # Two pair → one more card makes full house
    if len(pairs) == 2:
        involved = [c for c in cards if parse(c)[0] in pairs]
        return (6, involved)

    # --- 5: Flush ---
    for suit, count in suit_count.items():
        if count == 4:
            near = [c for c in cards if c[1].lower() == suit]
            return (5, near)

    # --- 4: Straight ---
    uniq = sorted(set(ranks))
    for low in range(2, 11):
        window = {low+i for i in range(5)}
        have = window & set(uniq)
        if len(have) == 4:
            involved = [c for c in cards if parse(c)[0] in have]
            return (4, involved)

    # Wheel straight A-5
    wheel = {14, 2, 3, 4, 5}
    if len(wheel & set(uniq)) == 4:
        involved = [c for c in cards if parse(c)[0] in wheel]
        return (4, involved)

    # --- 3: Three of a Kind ---
    for r, c in rank_count.items():
        if c == 2:
            near = [c for c in cards if parse(c)[0] == r]
            return (3, near)

    # --- 2: Two Pair ---
    pairs = [r for r, c in rank_count.items() if c == 2]
    if len(pairs) == 1:
        near = [c for c in cards if parse(c)[0] == pairs[0]]
        return (2, near)

    # --- 1: One Pair ---
    for r, c in rank_count.items():
        if c == 1:
            involved = [c for c in cards if parse(c)[0] == r]
            return (1, involved)

    return (0, [])

values = {}
values[2] = [1, 2, 5, 15, 50]
values[5] = [1, 2, 13.1, 34.8, 131.6, 270.3, 588.2, 3921.5, 64935]
values[6] = [1.0, 1.5, 4.3, 11.0, 17.9, 32.3, 67.3, 890.1, 6126.7]
values[7] = [1, 1.2, 2.6, 6.5, 9.6, 17.2, 35.7, 502, 3215]

# DO NOT MODIFY THE FUNCTION SIGNATURE
def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    num_cards = len(state.community_cards) + len(state.player_cards)
    
    best_hand = get_best_hand_from(state.player_cards, state.community_cards)
    hand_value = best_hand[0]
    best_cards = best_hand[1]

    hand_value = values[num_cards][hand_value]
    hand_value *= (get_cards_in_hand(state.player_cards, best_cards) + 0.5)

    potential_hand = get_one_away(state.player_cards, state.community_cards)
    potential_hand_value = potential_hand[0]
    potential_best_cards = potential_hand[1]
    potential_hand_value = math.sqrt(values[num_cards][potential_hand_value])
    potential_hand_value *= (get_cards_in_hand(state.player_cards, potential_best_cards) + 0.5)
    hand_value += potential_hand_value
    
    money = state.held_money[state.index_to_action]
    to_call = amount_to_call(state)

    pots = get_my_pots(state)
    pot_value = 0
    for pot in pots:
        pot_value += pot.value

    max_possible = 100
    strength_norm = min(1.0, hand_value / max_possible)
    if (to_call > 100):
        strength_norm = strength_norm / math.sqrt(to_call / 100)

    fold_threshold = 0.02
    call_threshold = 0.06
    raise_threshold = 0.15
    shove_threshold = 0.40
    if num_cards == 2:
        return (to_call, memory)

    if strength_norm < fold_threshold:
        return (0 if to_call == 0 else -1, memory)

    if strength_norm < call_threshold:
        return (to_call, memory)

    if strength_norm < raise_threshold:
        raise_amount = int(pot_value * 0.25)
        return (max(to_call, raise_amount), memory)

    if strength_norm < shove_threshold:
        raise_amount = int(pot_value * 0.75)
        return (max(to_call, raise_amount), memory)

    return (money, memory)
    


def set_state_input(state: GameState):
    state.index_to_action = int(input())
    state.index_of_small_blind = int(input())
    state.players = input().split()
    state.player_cards = input().split()
    state.held_money = list(map(int, input().split()))
    state.bet_money = list(map(int, input().split()))
    state.community_cards = input().split()

    num_pots = int(input())
    state.pots = []
    for _ in range(num_pots):
        pot_input_list = input().split()
        p = Pot()
        p.value = int(pot_input_list[0])
        p.players = pot_input_list[1:]
        state.pots.append(p)

    state.small_blind = int(input())
    state.big_blind = int(input())


def main():
    state = GameState()

    set_state_input(state)
    
    filename = ".".join(sys.argv[0].split(".")[:-1]) + ".pkl"
    memory = None
    
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            memory = pickle.load(f)

    try:
        bet_amt, memory = bet(state, memory)
    
        if memory is not None:
            with open(filename, "wb") as f:
                pickle.dump(memory, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        bet_amt = -1
    
    print(bet_amt)


if __name__ == "__main__":
    main()
