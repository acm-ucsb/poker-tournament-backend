import pickle
import sys
import os

# class Pot:
#     value: int
#     players: list[str]


# class GameState:
#     index_to_action: int
#     index_of_small_blind: int
#     players: list[str]
#     player_cards: list[str]
#     held_money: list[int]
#     bet_money: list[int]
#     community_cards: list[str]
#     pots: list[Pot]
#     small_blind: int
#     big_blind: int

# class Memory:
#     pass

# ======================= #
# ACTUAL BOT CODE HERE!!! #
# ======================= #
# <IMPORTS HERE>
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations
import hashlib
import random

# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *


class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int


# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """


@dataclass
class Memory:
    last_equity: float = 0.0
    last_action: int = 0
    last_round: str = "Pre-Flop"
    samples: int = 0


CARD_RANKS = "23456789tjqka"
CARD_SUITS = "sdch"
FULL_DECK = tuple(f"{rank}{suit}" for rank in CARD_RANKS for suit in CARD_SUITS)
HAND_CATEGORY_NAMES = {
    0: "High Card",
    1: "Pair",
    2: "Two Pair",
    3: "Three of a Kind",
    4: "Straight",
    5: "Flush",
    6: "Full House",
    7: "Four of a Kind",
    8: "Straight Flush",
}


def _canonical_card(card: str) -> str:
    return card.strip().lower()


def _sorted_cards_key(cards: list[str]) -> tuple[str, ...]:
    return tuple(sorted(cards))


def _straight_high(unique_desc_ranks: list[int]) -> int:
    if len(unique_desc_ranks) < 5:
        # wheel check still possible
        if set(unique_desc_ranks) >= {14, 5, 4, 3, 2}:
            return 5
        return 0
    for idx in range(len(unique_desc_ranks) - 4):
        high = unique_desc_ranks[idx]
        low = unique_desc_ranks[idx + 4]
        if high - low == 4:
            return high
    ranks_set = set(unique_desc_ranks)
    if {14, 5, 4, 3, 2}.issubset(ranks_set):
        return 5
    return 0


def _evaluate_five(cards5: tuple[str, ...]) -> tuple[int, tuple[int, ...]]:
    parsed = [parse_card(card) for card in cards5]
    ranks = sorted((rank for rank, _ in parsed), reverse=True)
    suits = [suit for _, suit in parsed]
    counts = Counter(ranks)
    grouped = sorted(
        ((count, rank) for rank, count in counts.items()),
        key=lambda item: (item[0], item[1]),
        reverse=True,
    )
    is_flush = len(set(suits)) == 1
    unique_desc = sorted(set(ranks), reverse=True)
    straight_high = _straight_high(unique_desc)

    if is_flush and straight_high:
        return (8, (straight_high,))

    if grouped[0][0] == 4:
        four_rank = grouped[0][1]
        kicker = max(rank for rank in ranks if rank != four_rank)
        return (7, (four_rank, kicker))

    if grouped[0][0] == 3:
        pair_rank = None
        for count, rank in grouped[1:]:
            if count >= 2:
                pair_rank = rank
                break
        if pair_rank is not None:
            return (6, (grouped[0][1], pair_rank))

    if is_flush:
        return (5, tuple(ranks))

    if straight_high:
        return (4, (straight_high,))

    if grouped[0][0] == 3:
        trips_rank = grouped[0][1]
        kickers = tuple(rank for rank in ranks if rank != trips_rank)
        return (3, (trips_rank,) + kickers)

    pair_ranks = sorted((rank for count, rank in grouped if count == 2), reverse=True)
    if len(pair_ranks) >= 2:
        high_pair, low_pair = pair_ranks[:2]
        kicker = max(rank for rank in ranks if rank != high_pair and rank != low_pair)
        return (2, (high_pair, low_pair, kicker))

    if len(pair_ranks) == 1:
        pair_rank = pair_ranks[0]
        kickers = tuple(rank for rank in ranks if rank != pair_rank)
        return (1, (pair_rank,) + kickers)

    return (0, tuple(ranks))


@lru_cache(maxsize=20000)
def _best_rank_from_key(cards_key: tuple[str, ...]) -> tuple[int, tuple[int, ...]]:
    if len(cards_key) < 5:
        raise ValueError("At least 5 cards are required to evaluate a hand.")
    best_rank = (-1, ())
    for combo in combinations(cards_key, 5):
        rank = _evaluate_five(combo)
        if rank > best_rank:
            best_rank = rank
    return best_rank


def _rank_from_cards(cards: list[str]) -> tuple[int, tuple[int, ...]]:
    return _best_rank_from_key(_sorted_cards_key(cards))


def _current_hand_category(hero_cards: list[str], community_cards: list[str]) -> str | None:
    cards = hero_cards + community_cards
    if len(cards) < 5:
        return None
    category = _rank_from_cards(cards)[0]
    return HAND_CATEGORY_NAMES.get(category)


def _pot_players(pot: Pot) -> list[str]:
    if hasattr(pot, "players"):
        return list(pot.players)
    return list(pot.get("players", [])) if isinstance(pot, dict) else []


def _opponents_in_pot(state: GameState) -> list[int]:
    hero_index = state.index_to_action
    hero_id = state.players[hero_index]
    relevant_players: set[str] = set()
    for pot in state.pots or []:
        players = _pot_players(pot)
        if hero_id in players:
            relevant_players.update(players)
    opponents: list[int] = []
    for idx, name in enumerate(state.players):
        if idx == hero_index:
            continue
        if state.bet_money[idx] == -1:
            continue
        if relevant_players and name not in relevant_players:
            continue
        opponents.append(idx)
    if not opponents:
        opponents = [idx for idx in range(len(state.players)) if idx != hero_index and state.bet_money[idx] != -1]
    return opponents


def _state_seed(hero_cards: list[str], community_cards: list[str], state: GameState) -> int:
    parts = [
        "".join(sorted(hero_cards)),
        "".join(sorted(community_cards)),
        ",".join(map(str, state.bet_money)),
        ",".join(map(str, state.held_money)),
        str(state.index_to_action),
    ]
    digest = hashlib.sha256("|".join(parts).encode()).digest()
    return int.from_bytes(digest[:8], "big")


def _sample_count(cards_needed: int, opponents: int) -> int:
    if cards_needed <= 4:
        return 2600
    if cards_needed <= 6:
        return 1700
    if cards_needed <= 8:
        return 1100
    return max(600, 400 + opponents * 150)


def _estimate_equity(state: GameState) -> dict[str, float | int | str | None]:
    hero_cards = [_canonical_card(card) for card in state.player_cards if card]
    community_cards = [_canonical_card(card) for card in state.community_cards if card]
    round_name = get_round_name(state)
    if len(hero_cards) < 2:
        return {
            "equity": 0.0,
            "win_rate": 0.0,
            "tie_rate": 0.0,
            "samples": 0,
            "round": round_name,
            "active_opponents": 0,
            "made_category": None,
        }

    opponents = _opponents_in_pot(state)
    active_opponents = len(opponents)
    made_category = _current_hand_category(hero_cards, community_cards)
    if active_opponents == 0:
        return {
            "equity": 1.0,
            "win_rate": 1.0,
            "tie_rate": 0.0,
            "samples": 1,
            "round": round_name,
            "active_opponents": 0,
            "made_category": made_category,
        }

    used_cards = set(hero_cards + community_cards)
    deck = [card for card in FULL_DECK if card not in used_cards]
    unknown_board = max(0, 5 - len(community_cards))
    cards_needed = unknown_board + 2 * active_opponents
    if cards_needed > len(deck):
        # Fallback for inconsistent states where not enough cards remain.
        return {
            "equity": 0.5,
            "win_rate": 0.5,
            "tie_rate": 0.0,
            "samples": 1,
            "round": round_name,
            "active_opponents": active_opponents,
            "made_category": made_category,
        }
    samples = _sample_count(cards_needed, active_opponents)
    rng = random.Random(_state_seed(hero_cards, community_cards, state))

    wins_equivalent = 0.0
    pure_wins = 0
    ties = 0

    for _ in range(samples):
        draw = rng.sample(deck, cards_needed)
        future_board = draw[:unknown_board]
        hero_board = community_cards + list(future_board)
        offset = unknown_board
        opponent_hands = []
        for _ in range(active_opponents):
            opponent_hands.append([draw[offset], draw[offset + 1]])
            offset += 2

        hero_rank = _rank_from_cards(hero_cards + hero_board)
        best_rank = hero_rank
        hero_best = True
        winner_count = 1

        for opp_hand in opponent_hands:
            opp_rank = _rank_from_cards(opp_hand + hero_board)
            if opp_rank > best_rank:
                best_rank = opp_rank
                hero_best = False
                winner_count = 1
            elif opp_rank == best_rank:
                if hero_best:
                    winner_count += 1
                else:
                    winner_count += 1

        if hero_best:
            wins_equivalent += 1.0 / winner_count
            if winner_count == 1:
                pure_wins += 1
            else:
                ties += 1

    total_samples = samples if samples > 0 else 1
    equity = wins_equivalent / total_samples
    return {
        "equity": equity,
        "win_rate": pure_wins / total_samples,
        "tie_rate": ties / total_samples,
        "samples": total_samples,
        "round": round_name,
        "active_opponents": active_opponents,
        "made_category": made_category,
    }


def _aggression_threshold(round_name: str, opponents: int) -> float:
    base = {
        "Pre-Flop": 0.65,
        "Flop": 0.58,
        "Turn": 0.62,
        "River": 0.7,
    }.get(round_name, 0.6)
    adjustment = min(0.08, 0.02 * max(0, opponents - 1))
    return min(0.9, base + adjustment)


def _pick_raise_amount(state: GameState, legal: list[int], equity: float, pot_size: int, stack: int) -> int | None:
    to_call = amount_to_call(state)
    raise_options = sorted({amt for amt in legal if amt > max(0, to_call)})
    if not raise_options:
        return None
    min_raise_amt = min_raise(state)
    all_in_amt = all_in(state)
    pot_pressure = pot_size if pot_size > 0 else state.big_blind * 2

    if all_in_amt in raise_options and (equity >= 0.88 or stack <= pot_pressure):
        return all_in_amt
    if equity >= 0.75 and len(raise_options) > 1:
        return raise_options[-1]
    if min_raise_amt in raise_options:
        return min_raise_amt
    return raise_options[0]


def _select_action(state: GameState, equity_report: dict[str, float | int | str | None]) -> int:
    legal = legal_actions(state)
    if not legal:
        return 0
    to_call = amount_to_call(state)
    pot_size = total_pot(state)
    stack = my_stack(state)
    equity = float(equity_report["equity"])
    opponents = int(equity_report["active_opponents"])
    round_name = str(equity_report["round"])
    call_amount = call(state)
    fold_margin = 0.03 + 0.01 * max(0, opponents - 1)

    if to_call > 0:
        pot_odds = to_call / (pot_size + to_call) if pot_size + to_call > 0 else 1.0
        if equity + fold_margin < pot_odds and -1 in legal:
            return -1
        if equity - fold_margin > max(0.55, pot_odds + 0.1):
            raise_amt = _pick_raise_amount(state, legal, equity, pot_size, stack)
            if raise_amt is not None:
                return raise_amt
        if call_amount in legal:
            return call_amount
        if all_in(state) in legal:
            return all_in(state)
        return 0 if 0 in legal else legal[0]

    threshold = _aggression_threshold(round_name, opponents)
    if equity >= threshold:
        raise_amt = _pick_raise_amount(state, legal, equity, pot_size, stack)
        if raise_amt is not None:
            return raise_amt
    return 0 if 0 in legal else legal[0]


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""


def bet(state: GameState, memory: Memory | None = None) -> tuple[int, Memory | None]:
    if memory is None:
        memory = Memory()

    equity_report = _estimate_equity(state)
    bet_amount = _select_action(state, equity_report)

    memory.last_equity = float(equity_report["equity"])
    memory.last_action = bet_amount
    memory.last_round = str(equity_report["round"])
    memory.samples = int(equity_report["samples"])
    return (bet_amount, memory)


def set_state_input(state: GameState):
    state.index_to_action = int(input())
    state.index_of_small_blind = int(input())
    state.players = input().split()
    state.player_cards = input().split()
    state.held_money = list(map(int, input().split()))
    state.bet_money = list(map(int, input().split()))
    state.community_cards = input().split()

    num_pots = int(input())
    state.pots = []
    for _ in range(num_pots):
        pot_input_list = input().split()
        p = Pot()
        p.value = int(pot_input_list[0])
        p.players = pot_input_list[1:]
        state.pots.append(p)

    state.small_blind = int(input())
    state.big_blind = int(input())


def main():
    state = GameState()

    set_state_input(state)
    
    filename = ".".join(sys.argv[0].split(".")[:-1]) + ".pkl"
    memory = None
    
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            memory = pickle.load(f)

    try:
        bet_amt, memory = bet(state, memory)
    
        if memory is not None:
            with open(filename, "wb") as f:
                pickle.dump(memory, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        bet_amt = -1
    
    print(bet_amt)


if __name__ == "__main__":
    main()
