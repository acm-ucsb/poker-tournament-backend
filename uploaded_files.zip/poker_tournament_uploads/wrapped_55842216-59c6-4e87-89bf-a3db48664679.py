import pickle
import sys
import os

# class Pot:
#     value: int
#     players: list[str]


# class GameState:
#     index_to_action: int
#     index_of_small_blind: int
#     players: list[str]
#     player_cards: list[str]
#     held_money: list[int]
#     bet_money: list[int]
#     community_cards: list[str]
#     pots: list[Pot]
#     small_blind: int
#     big_blind: int

# class Memory:
#     pass

# ======================= #
# ACTUAL BOT CODE HERE!!! #
# ======================= #
# <IMPORTS HERE>
from typing import Optional
# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    def __init__(self):
        # Track opponent aggression and tendencies
        self.opp_raises = 0  # Times opponent raised
        self.opp_calls = 0   # Times opponent called
        self.opp_folds = 0   # Times opponent folded
        self.opp_checks = 0  # Times opponent checked
        self.opp_total_actions = 0
        
        # Track opponent preflop stats
        self.opp_preflop_raises = 0
        self.opp_preflop_calls = 0
        self.opp_preflop_folds = 0
        self.hands_played = 0
        
        # Track opponent postflop aggression
        self.opp_postflop_bets = 0
        self.opp_postflop_checks = 0
        
        # Track showdowns
        self.hands_seen = 0
        self.showdowns = 0
        
        # Track our own stats for adaptive play
        self.our_wins = 0
        self.our_losses = 0
        
        # Previous game state for tracking
        self.last_state = None
        self.last_pot = 0


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""

def round_bet_to_50(bet_amount: int, max_chips: int) -> int:
    """
    Round bet amount to nearest increment of 50.
    If rounding up exceeds max_chips, round down instead.
    
    Args:
        bet_amount: The raw bet amount to round
        max_chips: Maximum chips available (prevents rounding up beyond our stack)
    
    Returns:
        Rounded bet amount in increments of 50
    """
    if bet_amount <= 0:
        return bet_amount  # Don't round folds or checks
    
    # Calculate rounded up and down values
    rounded_down = (bet_amount // 50) * 50
    rounded_up = rounded_down + 50
    
    # If rounding up exceeds our chips, round down
    if rounded_up > max_chips:
        return min(rounded_down, max_chips)
    
    # Otherwise, round to nearest
    if bet_amount - rounded_down < rounded_up - bet_amount:
        return rounded_down
    else:
        return rounded_up


def get_preflop_strength(cards: list[str]) -> float:
    """
    Evaluate preflop hand strength (0.0 to 1.0)
    Higher is better
    """
    if len(cards) != 2:
        return 0.0
    
    card1, card2 = cards[0], cards[1]
    rank1, suit1 = parse_card(card1)
    rank2, suit2 = parse_card(card2)
    
    # Ensure rank1 >= rank2 for consistency
    if rank2 > rank1:
        rank1, rank2 = rank2, rank1
    
    is_pair = (rank1 == rank2)
    is_suited = (suit1 == suit2)
    gap = rank1 - rank2
    
    # Base strength on high card
    strength = (rank1 + rank2) / 28.0  # Max is (14+14)/28 = 1.0
    
    # Pair bonus (especially high pairs)
    if is_pair:
        pair_bonus = 0.3 + (rank1 / 14.0) * 0.4  # AA gets 0.7, 22 gets ~0.32
        strength += pair_bonus
    
    # Suited bonus
    if is_suited:
        strength += 0.1
    
    # Connected cards bonus (for straight potential)
    if gap <= 1 and not is_pair:
        strength += 0.05
    elif gap <= 2:
        strength += 0.02
    
    # High cards bonus (broadway cards)
    if rank1 >= 10 and rank2 >= 10:
        strength += 0.1
    
    # Premium hands boost
    if is_pair and rank1 >= 10:  # JJ+
        strength += 0.15
    
    # Ace with high kicker
    if rank1 == 14 and rank2 >= 10:
        strength += 0.1
    
    return min(strength, 1.0)


def get_postflop_strength(state: GameState) -> float:
    """
    Evaluate postflop hand strength (0.0 to 1.0)
    Takes into account current hand and potential
    """
    if not state.community_cards:
        return 0.0
    
    my_cards = state.player_cards
    community = state.community_cards
    
    if len(my_cards) + len(community) < 5:
        return 0.5  # Not enough cards to evaluate
    
    # Get our best hand
    hand_category, best_hand = get_best_hand_from(my_cards, community)
    
    # Hand category strengths with proper scaling
    # 0=High Card, 1=Pair, 2=Two Pair, 3=Trips, 4=Straight, 5=Flush, 6=Full House, 7=Quads, 8=Straight Flush
    category_strengths = {
        0: 0.10,  # High card - very weak
        1: 0.30,  # Pair - weak
        2: 0.50,  # Two pair - medium
        3: 0.65,  # Three of a kind - strong
        4: 0.75,  # Straight - strong
        5: 0.80,  # Flush - very strong
        6: 0.90,  # Full house - very strong
        7: 0.95,  # Four of a kind - extremely strong
        8: 1.00,  # Straight flush - nuts
    }
    
    base_strength = category_strengths.get(hand_category, 0.10)
    
    # Parse our best hand for tiebreakers
    if best_hand and hand_category >= 1:  # Pair or better
        best_ranks = sorted([parse_card(c)[0] for c in best_hand], reverse=True)
        # Add high card strength within category (up to 0.05 bonus)
        high_card_bonus = (best_ranks[0] / 14.0) * 0.05
        base_strength += high_card_bonus
    
    return min(base_strength, 1.0)


def calculate_pot_odds(state: GameState) -> float:
    """
    Calculate pot odds: amount to call / (pot + amount to call)
    Returns required equity to call profitably
    """
    to_call = amount_to_call(state)
    if to_call == 0:
        return 0.0
    
    pot = total_pot(state) + sum(max(0, b) for b in state.bet_money)
    required_equity = to_call / (pot + to_call)
    return required_equity


def calculate_optimal_bet_size(hand_strength: float, pot: int, my_chips: int, state: GameState) -> int:
    """
    Calculate optimal bet size based on hand strength (equity) and game theory
    
    Theory:
    - With strong hands (high equity): bet larger to extract value
    - With medium hands: bet smaller to control pot size
    - With weak hands (bluffs): bet to make opponent indifferent
    
    Formula: bet_size ≈ pot * (equity / (1 - equity))
    But capped at reasonable limits
    """
    # Estimate our equity (simplified - actual equity would require Monte Carlo simulation)
    equity = hand_strength
    
    # For very strong hands (equity > 0.7): bet 65-80% pot for value
    if equity >= 0.70:
        bet_fraction = 0.70 + (equity - 0.70) * 0.33  # Scales from 70% to 80%
        
    # For strong hands (equity 0.5-0.7): bet 50-65% pot
    elif equity >= 0.50:
        bet_fraction = 0.50 + (equity - 0.50) * 0.75  # Scales from 50% to 65%
        
    # For medium hands (equity 0.3-0.5): bet 33-50% pot
    elif equity >= 0.30:
        bet_fraction = 0.33 + (equity - 0.30) * 0.85  # Scales from 33% to 50%
        
    # For weak hands/bluffs (equity < 0.3): bet 40-50% pot (make them fold)
    else:
        bet_fraction = 0.40 + equity * 0.33  # Scales from 40% to 50%
    
    # Calculate actual bet size
    bet_size = int(pot * bet_fraction)
    
    # Apply constraints
    bet_size = max(bet_size, state.big_blind)  # Minimum bet
    bet_size = min(bet_size, my_chips)  # Can't bet more than we have
    
    # On river, be more aggressive with strong hands
    if len(state.community_cards) == 5 and equity >= 0.60:
        bet_size = min(int(bet_size * 1.15), my_chips)  # 15% increase on river
    
    return bet_size


def get_opponent_profile(memory: Memory) -> dict:
    """
    Analyze opponent tendencies and return profile
    Returns dict with: vpip, pfr, aggression, postflop_agg
    """
    # Handle missing attributes (backward compatibility with old memory files)
    if not memory or not hasattr(memory, 'hands_played') or memory.hands_played == 0:
        return {
            'vpip': 0.5,  # Assume average
            'pfr': 0.25,  # Assume average
            'aggression': 1.0,
            'postflop_agg': 0.5,
            'fold_to_raise': 0.5
        }
    
    # VPIP: Voluntarily Put money In Pot (preflop)
    vpip = 0.5
    if hasattr(memory, 'hands_played') and memory.hands_played > 0:
        opp_preflop_raises = getattr(memory, 'opp_preflop_raises', 0)
        opp_preflop_calls = getattr(memory, 'opp_preflop_calls', 0)
        voluntary_actions = opp_preflop_raises + opp_preflop_calls
        vpip = voluntary_actions / memory.hands_played
    
    # PFR: PreFlop Raise percentage
    pfr = 0.25
    if hasattr(memory, 'hands_played') and memory.hands_played > 0:
        opp_preflop_raises = getattr(memory, 'opp_preflop_raises', 0)
        pfr = opp_preflop_raises / memory.hands_played
    
    # Overall aggression factor
    aggression = 1.0
    opp_total_actions = getattr(memory, 'opp_total_actions', 0)
    if opp_total_actions > 0:
        aggressive_actions = getattr(memory, 'opp_raises', 0)
        passive_actions = getattr(memory, 'opp_calls', 0) + getattr(memory, 'opp_checks', 0)
        if passive_actions > 0:
            aggression = aggressive_actions / passive_actions
    
    # Postflop aggression
    postflop_agg = 0.5
    opp_postflop_bets = getattr(memory, 'opp_postflop_bets', 0)
    opp_postflop_checks = getattr(memory, 'opp_postflop_checks', 0)
    total_postflop = opp_postflop_bets + opp_postflop_checks
    if total_postflop > 0:
        postflop_agg = opp_postflop_bets / total_postflop
    
    # Fold to raise frequency
    fold_freq = 0.5
    opp_folds = getattr(memory, 'opp_folds', 0)
    opp_calls = getattr(memory, 'opp_calls', 0)
    opp_raises = getattr(memory, 'opp_raises', 0)
    if opp_folds + opp_calls + opp_raises > 0:
        fold_freq = opp_folds / (opp_folds + opp_calls + opp_raises)
    
    return {
        'vpip': min(vpip, 1.0),
        'pfr': min(pfr, 1.0),
        'aggression': min(aggression, 5.0),
        'postflop_agg': min(postflop_agg, 1.0),
        'fold_to_raise': min(fold_freq, 1.0),
        'player_type': classify_opponent(vpip, pfr, aggression)
    }


def classify_opponent(vpip: float, pfr: float, aggression: float) -> str:
    """
    Classify opponent into a category
    Returns: 'tight-passive', 'tight-aggressive', 'loose-passive', 'loose-aggressive'
    """
    is_loose = vpip > 0.35
    is_aggressive = aggression > 1.5 or pfr > 0.20
    
    if is_loose and is_aggressive:
        return 'loose-aggressive'  # LAG
    elif is_loose and not is_aggressive:
        return 'loose-passive'  # Calling station
    elif not is_loose and is_aggressive:
        return 'tight-aggressive'  # TAG (good player)
    else:
        return 'tight-passive'  # Nit


def get_aggression_factor(memory: Memory) -> float:
    """
    Calculate opponent's aggression factor
    Higher means more aggressive
    """
    if not memory:
        return 1.0
    
    # Use getattr for backward compatibility
    opp_raises = getattr(memory, 'opp_raises', 0)
    opp_calls = getattr(memory, 'opp_calls', 0)
    opp_folds = getattr(memory, 'opp_folds', 0)
    opp_checks = getattr(memory, 'opp_checks', 0)
    
    total_actions = opp_raises + opp_calls + opp_folds + opp_checks
    if total_actions == 0:
        return 1.0
    
    # Aggression = (raises + bets) / (calls + checks + folds)
    aggressive_actions = opp_raises
    passive_actions = opp_calls + opp_checks + opp_folds
    
    if passive_actions == 0:
        return 3.0  # Very aggressive
    
    aggression = aggressive_actions / passive_actions
    return min(aggression, 5.0)


def calculate_spr(state: GameState) -> float:
    """
    Calculate Stack-to-Pot Ratio (SPR)
    SPR = effective_stack / pot
    Low SPR (<3): Commit with top pair+
    Medium SPR (3-10): Standard play
    High SPR (>10): Only stack off with very strong hands
    
    Multi-player: uses smallest stack among active players
    """
    my_index = state.index_to_action
    my_chips = state.held_money[my_index]
    
    # Find smallest opponent stack (among active players who haven't folded)
    min_opponent_stack = float('inf')
    for i, bet in enumerate(state.bet_money):
        if i != my_index and bet != -1:  # Active player, not folded
            min_opponent_stack = min(min_opponent_stack, state.held_money[i])
    
    # If no active opponents, use our stack
    if min_opponent_stack == float('inf'):
        effective_stack = my_chips
    else:
        effective_stack = min(my_chips, min_opponent_stack)
    
    pot = total_pot(state) + sum(max(0, b) for b in state.bet_money)
    
    if pot == 0:
        return 999  # Very high SPR
    
    return effective_stack / pot


def count_outs_fast(state: GameState) -> int:
    """
    Fast outs calculation for common draws (flush, straight)
    Returns number of outs (cards that improve hand)
    """
    if len(state.community_cards) < 3:
        return 0  # Can't calculate draws preflop
    
    my_cards = state.player_cards
    community = state.community_cards
    
    outs = 0
    
    # Count flush draw outs (9 outs if 4 to flush)
    all_cards = my_cards + community
    suits = {}
    for card in all_cards:
        suit = card[1].lower()
        suits[suit] = suits.get(suit, 0) + 1
    
    # If we have 4 of same suit, we have flush draw (9 outs)
    for suit, count in suits.items():
        if count == 4:
            outs += 9
            break
    
    # Count open-ended straight draw (8 outs)
    # Simplified: check if we have connected cards
    ranks = []
    RANK_VALUES = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'t':10,'j':11,'q':12,'k':13,'a':14}
    for card in all_cards:
        rank = card[0].lower()
        ranks.append(RANK_VALUES.get(rank, 0))
    
    unique_ranks = sorted(set(ranks))
    
    # Check for 4 in a row (open-ended straight draw)
    for i in range(len(unique_ranks) - 3):
        if unique_ranks[i+3] - unique_ranks[i] == 3:
            outs += 8 if outs == 0 else 6  # 8 if no flush draw, 6 if we already counted flush
            break
    
    return outs


def estimate_equity_from_outs(outs: int, streets_remaining: int) -> float:
    """
    Quick equity estimation from outs
    Rule of 2 and 4: multiply outs by 2 (turn) or 4 (flop)
    """
    if streets_remaining == 2:  # Flop to river
        return min((outs * 4) / 100.0, 0.95)
    elif streets_remaining == 1:  # Turn to river
        return min((outs * 2) / 100.0, 0.95)
    else:
        return 0.0


def get_position_type(state: GameState) -> str:
    """
    Determine position type for multi-player tables
    Returns: 'early', 'middle', 'late' (button/cutoff), or 'blinds'
    """
    num_players = len(state.players)
    my_index = state.index_to_action
    sb_index = state.index_of_small_blind
    
    # For heads-up (2 players)
    if num_players == 2:
        return 'late' if my_index == sb_index else 'blinds'
    
    # For multi-player: calculate position relative to button
    # Button is small blind in heads-up, but one before SB in multi-player
    bb_index = (sb_index + 1) % num_players
    button_index = (sb_index - 1) % num_players
    
    # Calculate seats after button
    seats_after_button = (my_index - button_index) % num_players
    
    # Position classification
    if my_index == sb_index or my_index == bb_index:
        return 'blinds'
    elif seats_after_button <= 2:  # Button, cutoff
        return 'late'
    elif seats_after_button <= 4:  # Middle position
        return 'middle'
    else:  # Early position (UTG, UTG+1, etc.)
        return 'early'


def get_stack_ratio(state: GameState) -> float:
    """
    Calculate our stack size relative to big blinds (M-ratio approximation)
    """
    my_index = state.index_to_action
    my_chips = state.held_money[my_index]
    bb = state.big_blind
    return my_chips / bb if bb > 0 else 0


def bet(state: GameState, memory: Optional[Memory] = None) -> tuple[int, Optional[Memory]]:
    """
    Main betting decision function
    """
    # Initialize memory if needed
    if memory is None:
        memory = Memory()
    
    # Get basic information
    my_index = state.index_to_action
    my_chips = state.held_money[my_index]
    to_call = amount_to_call(state)
    pot = int(total_pot(state) + sum(max(0, b) for b in state.bet_money))
    
    # Get position info
    is_button = (state.index_of_small_blind == my_index)
    
    # Get legal actions
    actions = legal_actions(state)
    
    # Can't do anything without chips
    if my_chips == 0:
        return (0, memory)
    
    # === PREFLOP STRATEGY ===
    if len(state.community_cards) == 0:
        hand_strength = get_preflop_strength(state.player_cards)
        position = get_position_type(state)
        
        # Adjust hand requirements based on position (multi-player)
        # Tighten up in early position, loosen in late position
        if position == 'early':
            strength_multiplier = 1.15  # Need 15% stronger hands
        elif position == 'middle':
            strength_multiplier = 1.05  # Need 5% stronger hands
        elif position == 'late':
            strength_multiplier = 0.90  # Can play 10% weaker hands
        else:  # blinds
            strength_multiplier = 1.0
        
        # Very strong hands (top 10%): AA, KK, QQ, AK
        if hand_strength >= 0.85 / strength_multiplier:
            if to_call == 0:
                # Raise big
                raise_amount = state.big_blind * 3
                raise_amount = round_bet_to_50(raise_amount, my_chips)
                if raise_amount <= my_chips:
                    return (raise_amount, memory)
                else:
                    return (round_bet_to_50(my_chips, my_chips), memory)  # All-in
            else:
                # Always commit with premium hands
                if to_call <= my_chips * 0.5:
                    # Re-raise aggressively
                    raise_size = int(min(to_call * 3, my_chips))
                    raise_size = round_bet_to_50(raise_size, my_chips)
                    return (raise_size, memory)
                else:
                    # Call big bets
                    return (round_bet_to_50(to_call, my_chips), memory)
        
        # Strong hands (top 20%): JJ, TT, AQ, AJ, KQ
        elif hand_strength >= 0.70 / strength_multiplier:
            if to_call == 0:
                # Raise
                raise_amount = state.big_blind * 2
                raise_amount = round_bet_to_50(raise_amount, my_chips)
                if raise_amount <= my_chips:
                    return (raise_amount, memory)
                return (round_bet_to_50(my_chips, my_chips), memory)
            elif to_call <= state.big_blind * 4:
                # Call moderate raises
                return (round_bet_to_50(to_call, my_chips), memory)
            else:
                # Fold to very big raises
                return (fold(), memory)
        
        # Playable hands (top 35%): 99-77, AT, KJ, QJ, suited connectors
        elif hand_strength >= 0.55 / strength_multiplier:
            if to_call == 0:
                # Raise on button, limp otherwise
                if is_button:
                    raise_amount = state.big_blind * 2
                    raise_amount = round_bet_to_50(raise_amount, my_chips)
                    if raise_amount <= my_chips:
                        return (raise_amount, memory)
                return (0, memory)
            elif to_call <= state.big_blind * 2:
                # Call small raises
                return (round_bet_to_50(to_call, my_chips), memory)
            else:
                # Fold to big raises
                return (fold(), memory)
        
        # Medium hands (top 50%): smaller pairs, suited cards
        elif hand_strength >= 0.45 / strength_multiplier:
            if to_call == 0:
                return (0, memory)  # Limp/check
            elif to_call <= state.big_blind:
                # Call very small raises
                return (round_bet_to_50(to_call, my_chips), memory)
            else:
                return (fold(), memory)
        
        # Weak hands - fold to any raise
        else:
            if to_call == 0:
                return (0, memory)  # Check
            else:
                return (fold(), memory)  # Fold
    
    # === POSTFLOP STRATEGY ===
    else:
        hand_strength = get_postflop_strength(state)
        required_equity = calculate_pot_odds(state)
        aggression = get_aggression_factor(memory)
        
        # Calculate draws and adjust hand strength
        outs = count_outs_fast(state)
        streets_left = 5 - len(state.community_cards)
        draw_equity = estimate_equity_from_outs(outs, streets_left)
        
        # If we have a draw, boost hand strength slightly
        if outs >= 8 and hand_strength < 0.50:  # Strong draw (8+ outs)
            hand_strength = max(hand_strength, 0.35 + draw_equity * 0.3)
        elif outs >= 4 and hand_strength < 0.30:  # Marginal draw (4-7 outs)
            hand_strength = max(hand_strength, 0.20 + draw_equity * 0.2)
        
        # SPR adjustments
        spr = calculate_spr(state)
        
        # Get opponent profile for exploitation
        opp_profile = get_opponent_profile(memory)
        
        # Monster hands (trips+): Bet/raise very aggressively
        if hand_strength >= 0.65:
            if to_call == 0:
                # Use equity-based bet sizing for value
                bet_size = calculate_optimal_bet_size(hand_strength, pot, my_chips, state)
                
                # Against tight-passive, bet bigger (they won't call anyway)
                if opp_profile['player_type'] == 'tight-passive':
                    bet_size = min(int(bet_size * 0.9), my_chips)  # Slightly smaller
                # Against loose-passive (calling station), bet bigger for value
                elif opp_profile['player_type'] == 'loose-passive':
                    bet_size = min(int(bet_size * 1.1), my_chips)
                
                bet_size = round_bet_to_50(bet_size, my_chips)
                return (bet_size, memory)
            else:
                # Low SPR: just commit with monsters
                if spr < 3:
                    return (round_bet_to_50(my_chips, my_chips), memory)  # All-in
                
                # Always raise with monsters (unless all-in)
                if to_call < my_chips * 0.7:
                    raise_size = int(min(to_call * 3, my_chips))
                    raise_size = round_bet_to_50(raise_size, my_chips)
                    if raise_size >= min_raise(state):
                        return (raise_size, memory)
                # Call any bet with monster hands
                return (round_bet_to_50(to_call, my_chips), memory)
        
        # Very strong hands (two pair, strong pair): Bet aggressively
        elif hand_strength >= 0.45:
            if to_call == 0:
                # Use equity-based bet sizing
                bet_size = calculate_optimal_bet_size(hand_strength, pot, my_chips, state)
                bet_size = round_bet_to_50(bet_size, my_chips)
                return (bet_size, memory)
            else:
                # Low SPR: commit with strong hands
                if spr < 3 and hand_strength >= 0.55:
                    return (round_bet_to_50(my_chips, my_chips), memory)  # All-in
                
                # Raise medium bets, call large bets
                if to_call <= pot * 0.7:
                    raise_size = int(min(to_call * 2.5, my_chips))
                    raise_size = round_bet_to_50(raise_size, my_chips)
                    if raise_size >= min_raise(state):
                        return (raise_size, memory)
                # Call
                return (round_bet_to_50(to_call, my_chips), memory)
        
        # Good hands (pair, draws): Bet medium or call based on equity
        elif hand_strength >= 0.28:
            if to_call == 0:
                # Use equity-based bet sizing
                bet_size = calculate_optimal_bet_size(hand_strength, pot, my_chips, state)
                bet_size = round_bet_to_50(bet_size, my_chips)
                if bet_size >= state.big_blind:
                    return (bet_size, memory)
                return (0, memory)
            else:
                # Call if pot odds justify it (equity-based decision)
                if hand_strength >= required_equity * 0.9:  # Need 90% of required equity
                    return (round_bet_to_50(to_call, my_chips), memory)
                elif to_call <= my_chips * 0.3:  # Or if bet is very small
                    return (round_bet_to_50(to_call, my_chips), memory)
                else:
                    return (fold(), memory)
        
        # Marginal hands: Check/call small or fold based on equity
        elif hand_strength >= 0.15:
            if to_call == 0:
                # Check (too weak to bet)
                return (0, memory)
            else:
                # Only call if we have correct pot odds
                if hand_strength >= required_equity:
                    return (round_bet_to_50(to_call, my_chips), memory)
                else:
                    return (fold(), memory)
        
        # Weak hands: Check/fold or occasional equity-based bluff
        else:
            if to_call == 0:
                # Bluff more against tight players who fold too much
                should_bluff = False
                if is_button and len(state.community_cards) >= 4:
                    should_bluff = True
                # Exploit tight players
                elif opp_profile['fold_to_raise'] > 0.60 and len(state.community_cards) >= 3:
                    should_bluff = True  # They fold too much
                
                if should_bluff:
                    # Small bluff - use equity-based sizing
                    bluff_size = calculate_optimal_bet_size(hand_strength, pot, my_chips, state)
                    bluff_size = round_bet_to_50(bluff_size, my_chips)
                    if bluff_size <= my_chips * 0.3:  # Only bluff small
                        return (bluff_size, memory)
                return (0, memory)
            else:
                # Fold weak hands (no equity to continue)
                return (fold(), memory)

def set_state_input(state: GameState):
    state.index_to_action = int(input())
    state.index_of_small_blind = int(input())
    state.players = input().split()
    state.player_cards = input().split()
    state.held_money = list(map(int, input().split()))
    state.bet_money = list(map(int, input().split()))
    state.community_cards = input().split()

    num_pots = int(input())
    state.pots = []
    for _ in range(num_pots):
        pot_input_list = input().split()
        p = Pot()
        p.value = int(pot_input_list[0])
        p.players = pot_input_list[1:]
        state.pots.append(p)

    state.small_blind = int(input())
    state.big_blind = int(input())


def main():
    state = GameState()

    set_state_input(state)
    
    filename = ".".join(sys.argv[0].split(".")[:-1]) + ".pkl"
    memory = None
    
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            memory = pickle.load(f)

    try:
        bet_amt, memory = bet(state, memory)
    
        if memory is not None:
            with open(filename, "wb") as f:
                pickle.dump(memory, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        bet_amt = -1
    
    print(bet_amt)


if __name__ == "__main__":
    main()
