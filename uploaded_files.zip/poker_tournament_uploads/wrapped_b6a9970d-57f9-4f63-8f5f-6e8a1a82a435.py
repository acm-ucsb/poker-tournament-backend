import pickle
import sys
import os

# class Pot:
#     value: int
#     players: list[str]


# class GameState:
#     index_to_action: int
#     index_of_small_blind: int
#     players: list[str]
#     player_cards: list[str]
#     held_money: list[int]
#     bet_money: list[int]
#     community_cards: list[str]
#     pots: list[Pot]
#     small_blind: int
#     big_blind: int

# class Memory:
#     pass

# ======================= #
# ACTUAL BOT CODE HERE!!! #
# ======================= #
# <IMPORTS HERE>

# </IMPORTS HERE>

# <DO NOT MODIFY>
from helpers import *

class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    last_opponent_action: int = 0


""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""
# DO NOT MODIFY THE FUNCTION SIGNATURE
def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    if memory is None:
        memory = Memory()
        
    # Pre-Flop: always call
    if(get_round_name(state) == "Pre-Flop"):
        return call(state), memory
    
    # Check opponent's current bet in this betting round
    opponent_index = (state.index_to_action - 1) % len(state.players)
    opponent_current_bet = state.bet_money[opponent_index]
    
    # Store it in memory for reference
    memory.last_opponent_action = opponent_current_bet
    
    # If opponent checked (bet is 0), do min_raise
    if(opponent_current_bet == 0):
        return min_raise(state), memory
    
    # If opponent raised (bet > 0), fold
    return fold(), memory


def set_state_input(state: GameState):
    state.index_to_action = int(input())
    state.index_of_small_blind = int(input())
    state.players = input().split()
    state.player_cards = input().split()
    state.held_money = list(map(int, input().split()))
    state.bet_money = list(map(int, input().split()))
    state.community_cards = input().split()

    num_pots = int(input())
    state.pots = []
    for _ in range(num_pots):
        pot_input_list = input().split()
        p = Pot()
        p.value = int(pot_input_list[0])
        p.players = pot_input_list[1:]
        state.pots.append(p)

    state.small_blind = int(input())
    state.big_blind = int(input())


def main():
    state = GameState()

    set_state_input(state)
    
    filename = ".".join(sys.argv[0].split(".")[:-1]) + ".pkl"
    memory = None
    
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            memory = pickle.load(f)

    try:
        bet_amt, memory = bet(state, memory)
    
        if memory is not None:
            with open(filename, "wb") as f:
                pickle.dump(memory, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        bet_amt = -1
    
    print(bet_amt)


if __name__ == "__main__":
    main()
