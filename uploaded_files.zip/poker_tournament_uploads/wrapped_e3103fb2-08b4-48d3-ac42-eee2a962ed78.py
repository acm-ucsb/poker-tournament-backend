import pickle
import sys
import os

# class Pot:
#     value: int
#     players: list[str]


# class GameState:
#     index_to_action: int
#     index_of_small_blind: int
#     players: list[str]
#     player_cards: list[str]
#     held_money: list[int]
#     bet_money: list[int]
#     community_cards: list[str]
#     pots: list[Pot]
#     small_blind: int
#     big_blind: int

# class Memory:
#     pass

# ======================= #
# ACTUAL BOT CODE HERE!!! #
# ======================= #
# <IMPORTS HERE>

# </IMPORTS HERE>
import random
# <DO NOT MODIFY>
from helpers import *


class Pot:
    value: int
    players: list[str]


class GameState:
    index_to_action: int
    index_of_small_blind: int
    players: list[str]
    player_cards: list[str]
    held_money: list[int]
    bet_money: list[int]
    community_cards: list[str]
    pots: list[Pot]
    small_blind: int
    big_blind: int
# </DO NOT MODIFY>


""" Store any persistent data for your bot in this class """
class Memory:
    pass



""" Make a betting decision for the current turn.

    This function is called every time your bot needs to make a bet.

    Args:
        state (GameState): The current state of the game.
        memory (Memory | None): Your bot's memory from the previous turn, or None if this is the first turn.

    Returns:
        tuple[int, Memory | None]: A tuple containing:
            bet_amount: int - The amount you want to bet (-1 to fold, 0 to check, or any positive integer to raise)
            memory: Memory | None - Your bot's updated memory to be passed to the next turn
"""
def unparse_card(card_tuple: tuple[int, str]) -> str:
    rank_map = {
        2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9',
        10: 'T', 11: 'J', 12: 'Q', 13: 'K', 14: 'A'
    }
    numeric_rank, suit = card_tuple
    return f"{rank_map[numeric_rank]}{suit}"

def bet(state: GameState, memory: Memory | None=None) -> tuple[int, Memory | None]:
    call_amount = amount_to_call(state)
    my_chips = state.held_money[state.index_to_action]
    
    numberofwins = 0
    numberofties = 0
    deck = deck_remaining(state)
    for i in range(10000):
        int1 = random.randint(0,len(deck)-1)
        int2 = random.randint(0,len(deck)-1)
        while(int1 == int2):
            int2 = random.randint(0,len(deck)-1)
        if get_best_hand_from(state.player_cards,state.community_cards) > get_best_hand_from([unparse_card(deck[int1]),unparse_card(deck[int2])],state.community_cards):
            numberofwins += 1
        elif get_best_hand_from(state.player_cards,state.community_cards) == get_best_hand_from([unparse_card(deck[int1]),unparse_card(deck[int2])],state.community_cards):
            numberofties += 1
    handStrength = (numberofwins + (numberofties/2))/10000
    for pots in state.pots:
        if pots.players == state.players:
            potchips = pots.value
    if call(state) == 0:
        bestchance = 0
    else:
        if state.community_cards  == []:
            mult = max(state.bet_money)/abs(call(state)-200)
            bestchance = 1.0/mult
        else:
            mult = potchips/call(state)
            bestchance = 1.0/mult
    

    if handStrength > bestchance and state.held_money[state.index_to_action]> call_amount:
        # Also acts like a check if people dont bet anymore
        return (call(state),memory)
    elif handStrength > bestchance:
        return (all_in(state),memory)
    else:
        return (fold(),memory)  


    

def set_state_input(state: GameState):
    state.index_to_action = int(input())
    state.index_of_small_blind = int(input())
    state.players = input().split()
    state.player_cards = input().split()
    state.held_money = list(map(int, input().split()))
    state.bet_money = list(map(int, input().split()))
    state.community_cards = input().split()

    num_pots = int(input())
    state.pots = []
    for _ in range(num_pots):
        pot_input_list = input().split()
        p = Pot()
        p.value = int(pot_input_list[0])
        p.players = pot_input_list[1:]
        state.pots.append(p)

    state.small_blind = int(input())
    state.big_blind = int(input())


def main():
    state = GameState()

    set_state_input(state)
    
    filename = ".".join(sys.argv[0].split(".")[:-1]) + ".pkl"
    memory = None
    
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            memory = pickle.load(f)

    try:
        bet_amt, memory = bet(state, memory)
    
        if memory is not None:
            with open(filename, "wb") as f:
                pickle.dump(memory, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        bet_amt = -1
    
    print(bet_amt)


if __name__ == "__main__":
    main()
